// ===================== MATERIALS =====================
export const materials = [
  // BEGINNER
  {
    id: 1, level: 'beginner', topic: 'Aritmetika', title: 'Operasi Dasar & Sifat Bilangan',
    desc: 'Fondasi matematika: operasi bilangan, sifat-sifat, dan trik perhitungan cepat.',
    duration: '30 menit', xp: 50, icon: '🔢',
    content: [
      { type: 'text', text: 'Matematika olimpiade dimulai dari pemahaman mendalam tentang bilangan. Sifat-sifat dasar yang sering luput diperhatikan ternyata sangat krusial.' },
      { type: 'formula', text: 'a(b + c) = ab + ac  (Distributif)' },
      { type: 'formula', text: '(a + b)² = a² + 2ab + b²' },
      { type: 'text', text: 'Trik cepat: untuk menghitung n², gunakan (n-1)(n+1) + 1. Contoh: 47² = 46 × 48 + 1 = 2208 + 1 = 2209.' },
      { type: 'example', title: 'Contoh Soal', text: 'Hitung 1 + 2 + 3 + ... + 100.\nSolusi: Pasangkan (1+100) + (2+99) + ... = 50 × 101 = 5050.' }
    ]
  },
  {
    id: 2, level: 'beginner', topic: 'Teori Bilangan', title: 'Faktor, Kelipatan & KPK/FPB',
    desc: 'Memahami keterbagian, mencari KPK dan FPB, serta algoritma Euclid.',
    duration: '45 menit', xp: 60, icon: '🧮',
    content: [
      { type: 'text', text: 'Teori bilangan adalah jantung olimpiade matematika. Keterbagian, bilangan prima, dan algoritma Euclid menjadi alat utama pemecahan masalah.' },
      { type: 'formula', text: 'FPB(a, b) = FPB(b, a mod b)  [Algoritma Euclid]' },
      { type: 'formula', text: 'KPK(a, b) = (a × b) / FPB(a, b)' },
      { type: 'example', title: 'Contoh', text: 'FPB(48, 18):\n48 = 2×18 + 12\n18 = 1×12 + 6\n12 = 2×6 + 0\nFPB = 6' }
    ]
  },
  {
    id: 3, level: 'beginner', topic: 'Geometri', title: 'Luas & Keliling Bangun Datar',
    desc: 'Segitiga, segiempat, lingkaran — rumus dan intuisi geometri dasar.',
    duration: '40 menit', xp: 55, icon: '📐',
    content: [
      { type: 'text', text: 'Geometri olimpiade menekankan intuisi visual dan pembuktian elegan, bukan hafalan rumus semata.' },
      { type: 'formula', text: 'L△ = ½ × alas × tinggi = √(s(s-a)(s-b)(s-c))  [Heron]' },
      { type: 'formula', text: 'L○ = πr²,  K○ = 2πr' },
    ]
  },
  // INTERMEDIATE
  {
    id: 4, level: 'intermediate', topic: 'Kombinatorik', title: 'Permutasi & Kombinasi',
    desc: 'Menghitung susunan dan pilihan — prinsip dasar kombinatorik.',
    duration: '60 menit', xp: 80, icon: '🎲',
    content: [
      { type: 'text', text: 'Kombinatorik adalah seni menghitung — tidak hanya dengan rumus, tetapi dengan prinsip-prinsip elegan seperti pigeonhole dan inklusi-eksklusi.' },
      { type: 'formula', text: 'P(n,k) = n! / (n-k)!' },
      { type: 'formula', text: 'C(n,k) = n! / (k!(n-k)!)' },
      { type: 'example', title: 'Pigeonhole', text: 'Di antara 13 orang, setidaknya 2 lahir di bulan yang sama.' }
    ]
  },
  {
    id: 5, level: 'intermediate', topic: 'Teori Bilangan', title: 'Kongruensi & Modular Aritmetika',
    desc: 'Sistem bilangan modular, teorema Fermat kecil, dan CRT.',
    duration: '75 menit', xp: 100, icon: '🔑',
    content: [
      { type: 'text', text: 'Aritmetika modular membuka dunia baru: bilangan "berputar" dalam siklus. Ini fondasi kriptografi dan banyak soal olimpiade level tinggi.' },
      { type: 'formula', text: 'a ≡ b (mod n)  ⟺  n | (a-b)' },
      { type: 'formula', text: 'Fermat Kecil: a^(p-1) ≡ 1 (mod p), p prima, gcd(a,p)=1' },
    ]
  },
  {
    id: 6, level: 'intermediate', topic: 'Aljabar', title: 'Pertidaksamaan Klasik',
    desc: 'AM-GM, Cauchy-Schwarz, dan teknik pembuktian ketidaksamaan.',
    duration: '90 menit', xp: 110, icon: '⚖️',
    content: [
      { type: 'formula', text: 'AM-GM: (a₁+a₂+...+aₙ)/n ≥ (a₁a₂...aₙ)^(1/n)' },
      { type: 'formula', text: 'Cauchy-Schwarz: (Σaᵢbᵢ)² ≤ (Σaᵢ²)(Σbᵢ²)' },
    ]
  },
  // ADVANCED
  {
    id: 7, level: 'advanced', topic: 'Kombinatorik', title: 'Prinsip Inklusi-Eksklusi',
    desc: 'Menghitung dengan PIE — teknik kombinatorik canggih.',
    duration: '80 menit', xp: 130, icon: '🕸️',
    content: [
      { type: 'formula', text: '|A∪B| = |A| + |B| - |A∩B|' },
      { type: 'formula', text: '|A∪B∪C| = |A|+|B|+|C| - |A∩B| - |A∩C| - |B∩C| + |A∩B∩C|' },
    ]
  },
  {
    id: 8, level: 'advanced', topic: 'Geometri', title: 'Geometri Proyektif & Transformasi',
    desc: 'Inversif, homothety, dan transformasi geometri lanjutan.',
    duration: '100 menit', xp: 150, icon: '🌀',
    content: [
      { type: 'text', text: 'Transformasi geometri mengubah soal sulit menjadi lebih sederhana. Inversif pada lingkaran adalah teknik paling elegan dalam geometri olimpiade.' },
    ]
  },
  {
    id: 9, level: 'advanced', topic: 'Teori Bilangan', title: 'Fungsi Aritmetika',
    desc: 'Fungsi Euler, Möbius, dan sifat-sifat fungsi multiplikatif.',
    duration: '90 menit', xp: 140, icon: '∮',
    content: [
      { type: 'formula', text: 'φ(n) = n ∏(1 - 1/p)  untuk semua prima p | n' },
    ]
  },
  // OLYMPIAD
  {
    id: 10, level: 'olympiad', topic: 'Kombinatorik', title: 'Teori Graf & Kombinatorik Ekstrem',
    desc: 'Ramsey theory, extremal combinatorics, dan aplikasinya di OSN/IMO.',
    duration: '120 menit', xp: 200, icon: '🕹️',
    content: []
  },
  {
    id: 11, level: 'olympiad', topic: 'Aljabar', title: 'Polinomial & Akar-Akar',
    desc: 'Vieta, Newton, dan teknik manipulasi polinomial level olimpiade.',
    duration: '110 menit', xp: 190, icon: '📈',
    content: [
      { type: 'formula', text: 'Vieta (kubik x³+bx²+cx+d): α+β+γ = -b/a, αβ+βγ+γα = c/a, αβγ = -d/a' },
    ]
  },
  {
    id: 12, level: 'olympiad', topic: 'Geometri', title: 'Geometri Lingkaran Lanjutan',
    desc: 'Power of a point, radical axis, coaxial circles.',
    duration: '120 menit', xp: 210, icon: '⭕',
    content: []
  },
  // IMO
  {
    id: 13, level: 'imo', topic: 'Kombinatorik', title: 'IMO Combinatorics: Difficult Cases',
    desc: 'Masalah IMO kombinatorik klasik dan teknik pemecahannya.',
    duration: '180 menit', xp: 350, icon: '🏆',
    content: []
  },
  {
    id: 14, level: 'imo', topic: 'Teori Bilangan', title: 'IMO Number Theory: Advanced Techniques',
    desc: 'Lifting the Exponent, p-adic valuations, Zsygmondy.',
    duration: '180 menit', xp: 350, icon: '🏆',
    content: [
      { type: 'formula', text: 'LTE (p|a-b): vₚ(aⁿ-bⁿ) = vₚ(a-b) + vₚ(n)' },
    ]
  },
]

// ===================== QUIZ QUESTIONS =====================
export const quizData = {
  beginner: [
    { id: 1, q: 'Berapakah nilai 1 + 2 + 3 + ... + 50?', opts: ['1225','1275','1300','1250'], ans: 1, xp: 10, hint: 'Gunakan rumus Gauss: n(n+1)/2' },
    { id: 2, q: 'FPB dari 36 dan 48 adalah?', opts: ['6','12','18','24'], ans: 1, xp: 10, hint: 'Gunakan algoritma Euclid' },
    { id: 3, q: 'Berapa banyak bilangan prima antara 1 dan 20?', opts: ['6','7','8','9'], ans: 2, xp: 10, hint: '2, 3, 5, 7, 11, 13, 17, 19' },
    { id: 4, q: 'Jika a + b = 10 dan ab = 21, maka a² + b² = ?', opts: ['58','62','58','100'], ans: 0, xp: 15, hint: 'Gunakan (a+b)² = a² + 2ab + b²' },
    { id: 5, q: 'KPK dari 4, 6, dan 9 adalah?', opts: ['36','72','18','24'], ans: 0, xp: 10, hint: 'Faktorkan setiap bilangan ke prima' },
  ],
  intermediate: [
    { id: 6, q: 'Berapa banyak cara menyusun 3 huruf berbeda dari kata "MATEMATIKA"?', opts: ['504','720','336','252'], ans: 0, xp: 20, hint: 'P(7,3) karena ada 7 huruf berbeda' },
    { id: 7, q: '2²⁰²³ mod 7 = ?', opts: ['1','2','4','6'], ans: 2, xp: 25, hint: 'Ord₇(2) = 3, maka 2023 mod 3 = ?' },
    { id: 8, q: 'Jika x + 1/x = 3, maka x³ + 1/x³ = ?', opts: ['18','27','24','21'], ans: 0, xp: 20 },
    { id: 9, q: 'Banyak cara memilih 2 buku dari 8 buku berbeda adalah?', opts: ['28','56','16','64'], ans: 0, xp: 15 },
    { id: 10, q: 'Nilai minimum dari x² + 4x + 7 adalah?', opts: ['3','7','4','2'], ans: 0, xp: 20 },
  ],
  advanced: [
    { id: 11, q: 'Jumlah semua pembagi positif dari 360 adalah?', opts: ['1170','1080','1260','990'], ans: 0, xp: 30 },
    { id: 12, q: 'Jika p adalah prima dan p | a² + b², apakah p | a dan p | b?', opts: ['Ya, selalu','Tidak, tidak harus','Hanya jika p=2','Hanya jika p>2'], ans: 1, xp: 35 },
    { id: 13, q: 'Banyak bilangan bulat positif ≤ 1000 yang tidak habis dibagi 2, 3, atau 5?', opts: ['267','266','268','265'], ans: 0, xp: 30 },
    { id: 14, q: 'AM dari {1, 2, ..., n} adalah (n+1)/2. GM-nya adalah sekitar?', opts: ['n/e','n/(2e)','√n','n/3'], ans: 0, xp: 40 },
  ],
  olympiad: [
    { id: 15, q: 'OSN 2019: Berapa banyak bilangan bulat positif n ≤ 2019 sehingga n³ - n habis dibagi 6?', opts: ['1344','1346','1343','1345'], ans: 0, xp: 60 },
    { id: 16, q: 'Jika a, b, c sisi segitiga, buktikan: a/(b+c) + b/(a+c) + c/(a+b) < 2. Nilai minimum ekspresi ini mendekati?', opts: ['1','1.5','2','0.5'], ans: 0, xp: 70 },
  ],
  imo: [
    { id: 17, q: 'IMO 2023 P1: Menentukan semua fungsi f: ℝ→ℝ memenuhi f(x+y)f(x-y)=(f(x)+f(y))²−4x²f(y). Berapa banyak solusi?', opts: ['1','2','3','Tak hingga'], ans: 1, xp: 100 },
    { id: 18, q: 'IMO 2022 P2: Jika n bilangan bulat positif dan a₁,...,aₙ bilangan real positif, pernyataan mana yang selalu benar?', opts: ['Σaᵢ ≥ n','Πaᵢ ≤ 1','Σaᵢ² ≥ Σaᵢ','Semua salah'], ans: 3, xp: 100 },
  ]
}

// ===================== PROBLEMS COLLECTION =====================
export const problems = [
  // SD level
  { id: 1, title: 'Lomba Matematika SD 2023 No. 1', source: 'Nasional', level: 'SD', topic: 'Aritmetika', year: 2023, country: 'Indonesia',
    problem: 'Toko A memiliki 240 apel. Setiap hari dijual 15 apel. Setelah berapa hari tersisa 45 apel?', answer: '13 hari' },
  { id: 2, title: 'Olimpiade Matematika SD Tingkat Kota 2022', source: 'Kota', level: 'SD', topic: 'Geometri', year: 2022, country: 'Indonesia',
    problem: 'Sebuah persegi panjang memiliki keliling 48 cm dan panjangnya dua kali lebarnya. Berapakah luas persegi panjang tersebut?', answer: '128 cm²' },
  // SMP level
  { id: 3, title: 'OSN SMP 2023 — Teori Bilangan', source: 'OSN', level: 'SMP', topic: 'Teori Bilangan', year: 2023, country: 'Indonesia',
    problem: 'Tentukan semua bilangan bulat positif n sehingga n² + 2n + 2023 merupakan bilangan kuadrat sempurna.', answer: 'n = 503' },
  { id: 4, title: 'Kangaroo Math 2023 (Grade 7-8)', source: 'Internasional', level: 'SMP', topic: 'Kombinatorik', year: 2023, country: 'Internasional',
    problem: 'Ada berapa cara menempatkan 3 benteng di papan catur 4×4 sehingga tidak ada dua benteng di baris atau kolom yang sama?', answer: '24' },
  // SMA level
  { id: 5, title: 'OSN SMA 2023 — Aljabar', source: 'OSN', level: 'SMA', topic: 'Aljabar', year: 2023, country: 'Indonesia',
    problem: 'Misalkan a, b, c bilangan real positif dengan a + b + c = 1. Buktikan bahwa ab + bc + ca ≤ 1/3.', answer: 'Gunakan AM-GM atau (a-b)²+(b-c)²+(c-a)² ≥ 0' },
  { id: 6, title: 'AIME 2023 Problem 7', source: 'AIME', level: 'SMA', topic: 'Teori Bilangan', year: 2023, country: 'USA',
    problem: 'Find the number of integers n with 1 ≤ n ≤ 2023 such that n(n+1)(n+2) is divisible by 24.', answer: '1012' },
  { id: 7, title: 'USAMO 2022 Problem 2', source: 'USAMO', level: 'SMA', topic: 'Geometri', year: 2022, country: 'USA',
    problem: 'In acute triangle ABC, let M be the midpoint of BC. Let P be the foot of the perpendicular from A to BM...', answer: 'Lihat solusi lengkap' },
  { id: 8, title: 'Baltic Way 2022 No. 12', source: 'Baltic Way', level: 'SMA', topic: 'Kombinatorik', year: 2022, country: 'Baltik',
    problem: 'Let n be a positive integer. Prove that among any 2n+1 integers, there exist three whose sum is divisible by 3.', answer: 'Gunakan Pigeonhole pada residue mod 3' },
  // IMO level
  { id: 9, title: 'IMO 2023 Problem 1', source: 'IMO', level: 'IMO', topic: 'Aljabar', year: 2023, country: 'Internasional',
    problem: 'Determine all composite integers n > 1 that satisfy the following property: if d₁, d₂, ..., dₖ are all the positive divisors of n with 1 = d₁ < d₂ < ... < dₖ = n, then dᵢ divides dᵢ₊₁ + dᵢ₊₂ for every 1 ≤ i ≤ k − 2.', answer: 'n = 4' },
  { id: 10, title: 'IMO 2022 Problem 3', source: 'IMO', level: 'IMO', topic: 'Kombinatorik', year: 2022, country: 'Internasional',
    problem: 'Let k be a positive integer and let S be a finite set of odd prime numbers. Prove that there is at most one way (up to rotation and reflection) to place the elements of S around a circle such that the product of any two adjacent elements is of the form x² + x + k for some positive integer x.', answer: 'Lihat solusi IMO 2022' },
  { id: 11, title: 'IMO 2021 Problem 2', source: 'IMO', level: 'IMO', topic: 'Teori Bilangan', year: 2021, country: 'Internasional',
    problem: 'Show that the inequality Σᵢ₌₁ⁿ Σⱼ₌₁ⁿ √|xᵢ - xⱼ| ≤ Σᵢ₌₁ⁿ Σⱼ₌₁ⁿ √|xᵢ + xⱼ| holds for all real numbers x₁, ..., xₙ.', answer: 'Cauchy-Schwarz + substitusi cerdas' },
  { id: 12, title: 'Shortlist IMO 2023 — C5', source: 'IMO Shortlist', level: 'IMO', topic: 'Kombinatorik', year: 2023, country: 'Internasional',
    problem: 'Let n be a positive integer. A row of n+1 squares is drawn. Two players take turns to colour the squares...', answer: 'Strategi optimal pemain pertama...' },
]

// ===================== PDF RESOURCES =====================
export const pdfResources = [
  { id: 1, title: 'ABTJOG — Aritmetika & Teori Bilangan', author: 'Tim OSN Indonesia', pages: 124, level: 'SMP-SMA', topic: 'Teori Bilangan', year: 2022, url: '#', desc: 'Materi komprehensif teori bilangan dari dasar hingga level OSN.' },
  { id: 2, title: 'AGMO Preparation Materials', author: 'Panitia AGMO', pages: 89, level: 'SMA-IMO', topic: 'Semua Topik', year: 2023, url: '#', desc: 'Materi resmi persiapan Asian and Pacific Mathematics Olympiad.' },
  { id: 3, title: 'Olympiad Combinatorics — Pranav A. Sriram', author: 'Pranav A. Sriram', pages: 273, level: 'Advanced-IMO', topic: 'Kombinatorik', year: 2020, url: '#', desc: 'Buku kombinatorik terlengkap untuk persiapan IMO.' },
  { id: 4, title: 'Problems in Combinatorics, Number Theory, and Geometry', author: 'T. Andreescu', pages: 198, level: 'SMA-IMO', topic: 'Semua Topik', year: 2018, url: '#', desc: 'Kumpulan masalah pilihan dari kompetisi internasional.' },
  { id: 5, title: 'Geometry Revisited — Coxeter & Greitzer', author: 'H.S.M. Coxeter', pages: 193, level: 'SMA-IMO', topic: 'Geometri', year: 1967, url: '#', desc: 'Klasik geometri olimpiade yang tak lekang waktu.' },
  { id: 6, title: 'Introduction to Inequalities — Olympiad Level', author: 'A. Engel', pages: 156, level: 'Intermediate-Advanced', topic: 'Aljabar', year: 2019, url: '#', desc: 'Dari AM-GM hingga SOS (Sum of Squares) technique.' },
  { id: 7, title: 'Soal-Soal OSN Matematika 2010-2023', author: 'Kemdikbud RI', pages: 312, level: 'SMA', topic: 'Semua Topik', year: 2023, url: '#', desc: 'Kumpulan soal OSN lengkap dengan kunci jawaban.' },
  { id: 8, title: 'IMO Compendium 2nd Edition', author: 'Djukić et al.', pages: 813, level: 'IMO', topic: 'Semua Topik', year: 2011, url: '#', desc: 'Semua soal IMO 1959-2009 beserta solusi.' },
  { id: 9, title: 'Putnam Problems & Solutions 2015-2023', author: 'Putnam Committee', pages: 245, level: 'Advanced-IMO', topic: 'Semua Topik', year: 2023, url: '#', desc: 'Soal kompetisi matematika perguruan tinggi bergengsi USA.' },
  { id: 10, title: 'Modul OSN SMP — Geometri Transformasi', author: 'Tim Pembina OSN', pages: 78, level: 'SMP', topic: 'Geometri', year: 2022, url: '#', desc: 'Materi geometri transformasi khusus OSN tingkat SMP.' },
]

// ===================== NEWS =====================
export const newsData = [
  {
    id: 1, title: 'Indonesia Raih 2 Medali Emas di IMO 2024!',
    date: '2024-07-21', category: 'Prestasi', readTime: '3 menit',
    preview: 'Tim IMO Indonesia berhasil membawa pulang 2 medali emas, 3 perak, dan 1 perunggu dari kompetisi bergengsi dunia yang diadakan di Bath, Inggris.',
    content: 'Tim Indonesia yang terdiri dari 6 siswa terbaik berhasil menorehkan prestasi membanggakan di panggung matematika dunia...',
    tags: ['IMO', 'Indonesia', 'Medali'], icon: '🥇', featured: true
  },
  {
    id: 2, title: 'OSN 2024 Tingkat Nasional Digelar di Lombok',
    date: '2024-09-10', category: 'Kompetisi', readTime: '2 menit',
    preview: 'Olimpiade Sains Nasional 2024 bidang Matematika akan diselenggarakan di Mataram, Nusa Tenggara Barat pada November 2024.',
    content: 'Persiapkan dirimu! OSN 2024 akan dihadiri oleh lebih dari 500 siswa SMP dan SMA terbaik dari seluruh Indonesia...',
    tags: ['OSN', '2024', 'Nasional'], icon: '🏆', featured: true
  },
  {
    id: 3, title: 'Fakta Menarik: Sejarah Panjang IMO sejak 1959',
    date: '2024-08-15', category: 'Fakta & Sejarah', readTime: '5 menit',
    preview: 'IMO pertama kali diadakan di Romania tahun 1959 dengan hanya 7 negara peserta. Kini lebih dari 100 negara berpartisipasi setiap tahunnya.',
    content: 'International Mathematical Olympiad dimulai sebagai inisiatif Romania untuk mempromosikan matematika di kalangan pelajar...',
    tags: ['Sejarah', 'IMO', 'Fakta'], icon: '📖', featured: false
  },
  {
    id: 4, title: 'Profil: Terence Tao, Peraih Medali Emas IMO Termuda',
    date: '2024-07-30', category: 'Profil', readTime: '4 menit',
    preview: 'Terence Tao meraih medali perunggu IMO pada usia 10 tahun, perak usia 11, dan emas usia 12 — rekor yang belum terpecahkan.',
    content: 'Terence Tao lahir di Adelaide, Australia pada 1975. Pada usia 2 tahun ia sudah bisa membaca...',
    tags: ['Profil', 'Terence Tao', 'Inspirasi'], icon: '⭐', featured: false
  },
  {
    id: 5, title: 'APMO 2025 — Soal dan Pembahasan Lengkap',
    date: '2025-03-15', category: 'Pembahasan Soal', readTime: '8 menit',
    preview: 'Asian Pacific Mathematics Olympiad 2025 telah usai. Simak soal lengkap beserta pembahasan elegan dari para ahli.',
    content: 'APMO 2025 diikuti oleh 37 negara dan wilayah. Soal tahun ini dinilai lebih bervariasi...',
    tags: ['APMO', '2025', 'Pembahasan'], icon: '📝', featured: false
  },
  {
    id: 6, title: 'Paradoks Matematika yang Akan Mengubah Cara Pandangmu',
    date: '2024-11-20', category: 'Fakta & Sejarah', readTime: '6 menit',
    preview: 'Dari Paradoks Banach-Tarski hingga Hilbert\'s Hotel — matematika penuh kejutan yang menantang intuisi manusia.',
    content: 'Paradoks Banach-Tarski menyatakan bahwa sebuah bola padat bisa dipecah dan disusun ulang menjadi dua bola dengan ukuran sama...',
    tags: ['Fakta', 'Paradoks', 'Menarik'], icon: '🤯', featured: false
  },
]

// ===================== COMPETITIONS =====================
export const competitions = [
  { id: 1, name: 'OSN Matematika 2025 — Tingkat Kabupaten', organizer: 'Dinas Pendidikan', date: '2025-03-01', deadline: '2025-02-15', level: 'SMP/SMA', type: 'Nasional', prize: 'Trofi + Uang Pembinaan', status: 'open', desc: 'Seleksi awal olimpiade matematika tingkat nasional. Soal meliputi aljabar, geometri, kombinatorik, dan teori bilangan.' },
  { id: 2, name: 'KOMPETISI MATEMATIKA SMAN 1 — Spring Cup 2025', organizer: 'SMAN 1 Jakarta', date: '2025-04-12', deadline: '2025-04-01', level: 'SMA', type: 'Sekolah', prize: 'Medali + Sertifikat', status: 'open', desc: 'Kompetisi internal bergengsi dengan soal level OSN. Terbuka untuk siswa kelas X-XII.' },
  { id: 3, name: 'APMO 2025 (Asian Pacific Mathematics Olympiad)', organizer: 'Panitia APMO', date: '2025-03-10', deadline: '2025-02-01', level: 'SMA (undangan)', type: 'Internasional', prize: 'Sertifikat Kehormatan', status: 'closed', desc: 'Olimpiade bergengsi tingkat Asia Pasifik. Diikuti oleh siswa undangan dari 37 negara.' },
  { id: 4, name: 'IMO 2025 — Melbourne, Australia', organizer: 'Panitia IMO', date: '2025-07-12', deadline: '2025-04-01', level: 'SMA (seleksi nasional)', type: 'Internasional', prize: 'Medali Emas/Perak/Perunggu', status: 'upcoming', desc: 'Olimpiade Matematika Internasional ke-66. Diikuti lebih dari 100 negara.' },
  { id: 5, name: 'KSM 2025 (Kompetisi Sains Madrasah)', organizer: 'Kemenag RI', date: '2025-08-05', deadline: '2025-06-30', level: 'MI/MTs/MA', type: 'Nasional', prize: 'Trofi + Beasiswa', status: 'upcoming', desc: 'Kompetisi sains nasional untuk siswa madrasah. Bidang matematika mencakup materi setara OSN.' },
  { id: 6, name: 'ITMO (Indonesian Team Mathematics Olympiad)', organizer: 'ITMO Committee', date: '2025-05-25', deadline: '2025-05-01', level: 'SMA', type: 'Tim', prize: 'Trofi + Uang Tunai', status: 'open', desc: 'Kompetisi berbasis tim (4 siswa). Format unik dengan relay round dan team round.' },
]

// ===================== FORUM POSTS =====================
export const forumPosts = [
  { id: 1, title: 'Tips Belajar Kombinatorik untuk Pemula', author: 'Budi Santoso', avatar: '🦁', date: '2025-01-15', topic: 'Kombinatorik', replies: 14, views: 234, pinned: true, content: 'Halo semua! Mau share pengalaman belajar kombinatorik dari nol. Menurut saya langkah pertama adalah...' },
  { id: 2, title: 'Bantuan: Soal OSN 2023 Teori Bilangan No. 5', author: 'Nisa Rahmah', avatar: '🦋', date: '2025-01-18', topic: 'Teori Bilangan', replies: 8, views: 127, content: 'Hei teman-teman, aku stuck di soal ini. Sudah coba mod 9 tapi tidak berhasil...' },
  { id: 3, title: 'Resource PDF Geometri Terbaik Menurut Kalian?', author: 'Ahmad Fauzi', avatar: '🐺', date: '2025-01-20', topic: 'Geometri', replies: 22, views: 456, content: 'Lagi cari referensi geometri transformasi. Sudah punya Geometry Revisited, ada rekomendasi lain?' },
  { id: 4, title: 'Persiapan OSN 2025 — Share Jadwal Belajar', author: 'Sari Dewi', avatar: '🦊', date: '2025-01-22', topic: 'Umum', replies: 35, views: 678, pinned: true, content: 'Yuk berbagi jadwal belajar masing-masing! Aku biasanya 2 jam/hari, fokus satu topik per minggu.' },
  { id: 5, title: 'Bukti Elegan Teorema Pythagoras — Koleksinya!', author: 'Rizky Pratama', avatar: '🐉', date: '2025-01-25', topic: 'Geometri', replies: 19, views: 312, content: 'Tau gak, ada ratusan bukti teorema Pythagoras. Mari kita kumpulkan yang paling elegan!' },
]
