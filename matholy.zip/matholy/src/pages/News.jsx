import React, { useState } from 'react'
import { newsData } from '../data'

const CATS = ['Semua', 'Prestasi', 'Kompetisi', 'Fakta & Sejarah', 'Profil', 'Pembahasan Soal']

export default function News() {
  const [cat, setCat] = useState('Semua')
  const [selected, setSelected] = useState(null)

  const filtered = newsData.filter(n => cat === 'Semua' || n.category === cat)

  if (selected) return (
    <div style={s.wrap}>
      <button onClick={() => setSelected(null)} style={s.back}>← Kembali ke Berita</button>
      <div style={s.articleCard}>
        <div style={s.artTop}>
          <span style={s.artIcon}>{selected.icon}</span>
          <div>
            <span style={s.artCat}>{selected.category}</span>
            <h1 style={s.artTitle}>{selected.title}</h1>
            <div style={s.artMeta}>{selected.date} · Baca {selected.readTime}</div>
          </div>
        </div>
        <div style={s.artTags}>{selected.tags.map((t, i) => <span key={i} style={s.tag}>#{t}</span>)}</div>
        <p style={s.artContent}>{selected.preview}</p>
        <p style={s.artContent}>{selected.content}</p>
        <div style={s.artContent}>
          <em style={{ color: 'var(--muted)', fontSize: 13 }}>Konten lengkap artikel akan segera hadir. Pantau terus MathOly untuk update terbaru!</em>
        </div>
      </div>
    </div>
  )

  const featured = newsData.find(n => n.featured)
  const rest = filtered.filter(n => !n.featured || cat !== 'Semua')

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.title}>Berita & Majalah Olimpiade</h1>
        <p style={s.desc}>Update terkini kompetisi, profil matematikawan, dan fakta menarik dunia matematika.</p>
      </div>

      {/* Featured */}
      {cat === 'Semua' && featured && (
        <button onClick={() => setSelected(featured)} style={s.featuredCard}>
          <div style={s.featuredLeft}>
            <span style={s.featuredBadge}>Unggulan</span>
            <span style={{ ...s.artCat, marginTop: 4, display: 'block' }}>{featured.category}</span>
            <h2 style={s.featuredTitle}>{featured.title}</h2>
            <p style={s.featuredPreview}>{featured.preview}</p>
            <div style={s.featuredMeta}>{featured.date} · {featured.readTime}</div>
          </div>
          <div style={s.featuredIcon}>{featured.icon}</div>
        </button>
      )}

      {/* Category tabs */}
      <div style={s.catRow}>
        {CATS.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{ ...s.catBtn, ...(cat === c ? s.catBtnActive : {}) }}>{c}</button>
        ))}
      </div>

      {/* Grid */}
      <div style={s.grid}>
        {filtered.map(n => (
          <button key={n.id} onClick={() => setSelected(n)} style={s.newsCard}>
            <div style={s.newsTop}>
              <span style={s.newsIcon}>{n.icon}</span>
              <span style={s.newsCat}>{n.category}</span>
            </div>
            <h3 style={s.newsTitle}>{n.title}</h3>
            <p style={s.newsPreview}>{n.preview}</p>
            <div style={s.newsMeta}>{n.date} · {n.readTime}</div>
            <div style={s.newsTags}>{n.tags.map((t, i) => <span key={i} style={s.tag}>#{t}</span>)}</div>
          </button>
        ))}
      </div>

      {filtered.length === 0 && <div style={s.empty}>Belum ada berita di kategori ini.</div>}
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1100, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 24 },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  featuredCard: { background: 'linear-gradient(135deg, #2c2825, #4a443e)', border: 'none', borderRadius: 'var(--radius-xl)', padding: '36px', color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 24, width: '100%', cursor: 'pointer', textAlign: 'left', marginBottom: 28 },
  featuredLeft: { flex: 1 },
  featuredBadge: { background: 'var(--amber)', color: '#2c2825', fontSize: 11, fontWeight: 700, padding: '3px 12px', borderRadius: 20, display: 'inline-block' },
  featuredTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(20px, 3vw, 28px)', marginBottom: 12, lineHeight: 1.3, color: 'white' },
  featuredPreview: { fontSize: 14, opacity: 0.8, lineHeight: 1.6, marginBottom: 12 },
  featuredMeta: { fontSize: 12, opacity: 0.6 },
  featuredIcon: { fontSize: 72, flexShrink: 0 },
  catRow: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 },
  catBtn: { padding: '6px 16px', borderRadius: 20, border: '1px solid var(--border)', background: 'white', fontSize: 13, cursor: 'pointer', color: 'var(--ink-light)' },
  catBtnActive: { background: 'var(--sage-dark)', color: 'white', borderColor: 'var(--sage-dark)', fontWeight: 600 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 20 },
  newsCard: { background: 'white', border: '1.5px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '22px', cursor: 'pointer', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 10, transition: 'all 0.15s' },
  newsTop: { display: 'flex', alignItems: 'center', gap: 10 },
  newsIcon: { fontSize: 28 },
  newsCat: { fontSize: 12, background: 'var(--warm-white)', border: '1px solid var(--border)', color: 'var(--muted)', padding: '3px 10px', borderRadius: 20, fontWeight: 500 },
  newsTitle: { fontFamily: 'var(--font-serif)', fontSize: 16, color: 'var(--ink)', lineHeight: 1.4, fontWeight: 600 },
  newsPreview: { fontSize: 13, color: 'var(--muted)', lineHeight: 1.55, flex: 1 },
  newsMeta: { fontSize: 12, color: 'var(--muted-light)', fontFamily: 'var(--font-mono)' },
  newsTags: { display: 'flex', gap: 6, flexWrap: 'wrap' },
  tag: { fontSize: 11, color: 'var(--sage-dark)', background: '#e8f2eb', padding: '2px 8px', borderRadius: 20 },
  back: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontSize: 14, cursor: 'pointer', marginBottom: 20, display: 'block' },
  articleCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '40px 36px', maxWidth: 780, margin: '0 auto' },
  artTop: { display: 'flex', gap: 20, marginBottom: 16 },
  artIcon: { fontSize: 48 },
  artCat: { fontSize: 12, background: 'var(--warm-white)', border: '1px solid var(--border)', color: 'var(--muted)', padding: '3px 10px', borderRadius: 20, fontWeight: 500 },
  artTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(22px, 3vw, 30px)', color: 'var(--ink)', marginTop: 8, marginBottom: 6, lineHeight: 1.3 },
  artMeta: { fontSize: 13, color: 'var(--muted-light)', fontFamily: 'var(--font-mono)' },
  artTags: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 },
  artContent: { fontSize: 16, color: 'var(--ink-light)', lineHeight: 1.8, marginBottom: 16, fontFamily: 'var(--font-serif)' },
  empty: { textAlign: 'center', padding: 60, color: 'var(--muted)' },
}
