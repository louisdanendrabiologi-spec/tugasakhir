import React from 'react'
import { useApp } from '../context/AppContext'
import { newsData, competitions, materials } from '../data'

export default function Home() {
  const { user, setPage } = useApp()

  const levelColors = { beginner: '#2a7a2a', intermediate: '#9a7220', advanced: '#9a4e2e', olympiad: '#6a3a9a', imo: '#c4a020' }
  const levelBgs = { beginner: '#e8f8e8', intermediate: '#fdf3dc', advanced: '#faeee8', olympiad: '#f0ebf8', imo: '#2c2825' }

  const upcomingComps = competitions.filter(c => c.status !== 'closed').slice(0, 3)
  const latestNews = newsData.slice(0, 3)
  const featuredMaterials = materials.slice(0, 4)

  return (
    <div style={s.wrap}>
      {/* Welcome */}
      <div style={s.welcome}>
        <div>
          <div style={s.welcomeHi}>Selamat datang kembali, {user.name.split(' ')[0]}! {user.avatar}</div>
          <div style={s.welcomeSub}>Terus belajar dan raih mimpimu di olimpiade matematika.</div>
        </div>
        <div style={s.streakBox}>
          <div style={s.streakFire}>🔥</div>
          <div>
            <div style={s.streakNum}>{user.streak}</div>
            <div style={s.streakLbl}>hari streak</div>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div style={s.statsRow}>
        {[
          { icon: '⭐', value: user.points.toLocaleString(), label: 'Total Poin', color: 'var(--amber)' },
          { icon: '🎖️', value: user.badges.length || 0, label: 'Lencana', color: 'var(--sage-dark)' },
          { icon: '📊', value: user.level, label: 'Level Saat Ini', color: 'var(--terracotta)' },
          { icon: '✅', value: '12', label: 'Materi Selesai', color: '#3a5a9a' },
        ].map((s2, i) => (
          <div key={i} style={s.statCard}>
            <div style={{ fontSize: 24, marginBottom: 8 }}>{s2.icon}</div>
            <div style={{ ...s.statVal, color: s2.color }}>{s2.value}</div>
            <div style={s.statLbl}>{s2.label}</div>
          </div>
        ))}
      </div>

      <div style={s.grid}>
        {/* Continue Learning */}
        <div style={s.section}>
          <div style={s.sectionHeader}>
            <h2 style={s.sectionTitle}>Lanjutkan Belajar</h2>
            <button style={s.seeAll} onClick={() => setPage('materials')}>Lihat semua →</button>
          </div>
          <div style={s.materialCards}>
            {featuredMaterials.map(m => (
              <button key={m.id} onClick={() => setPage('materials')} style={s.matCard}>
                <div style={s.matIcon}>{m.icon}</div>
                <div style={{ flex: 1 }}>
                  <div style={s.matTitle}>{m.title}</div>
                  <div style={s.matMeta}>{m.topic} • {m.duration}</div>
                </div>
                <span style={{ ...s.levelPill, background: levelBgs[m.level], color: levelColors[m.level] }}>
                  {m.level}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Right col */}
        <div>
          {/* Quick actions */}
          <div style={s.section}>
            <h2 style={s.sectionTitle}>Mulai Sekarang</h2>
            <div style={s.quickGrid}>
              {[
                { icon: '✏️', label: 'Ikuti Kuis', page: 'quiz', color: 'var(--sage-dark)', bg: '#e8f2eb' },
                { icon: '🧩', label: 'Coba Soal', page: 'problems', color: '#3a5a9a', bg: '#e8eef8' },
                { icon: '📄', label: 'Buka PDF', page: 'pdfs', color: '#9a4e2e', bg: '#faeee8' },
                { icon: '💬', label: 'Diskusi', page: 'forum', color: '#6a3a9a', bg: '#f0ebf8' },
              ].map((q, i) => (
                <button key={i} onClick={() => setPage(q.page)} style={{ ...s.quickBtn, background: q.bg, color: q.color }}>
                  <span style={{ fontSize: 24 }}>{q.icon}</span>
                  <span style={s.quickLabel}>{q.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Upcoming comps */}
          <div style={s.section}>
            <div style={s.sectionHeader}>
              <h2 style={s.sectionTitle}>Kompetisi Mendatang</h2>
              <button style={s.seeAll} onClick={() => setPage('competitions')}>Lihat semua →</button>
            </div>
            {upcomingComps.map(c => (
              <div key={c.id} style={s.compItem}>
                <div style={{ flex: 1 }}>
                  <div style={s.compName}>{c.name}</div>
                  <div style={s.compMeta}>{c.date} • {c.level}</div>
                </div>
                <span style={{ ...s.statusBadge, ...(c.status === 'open' ? s.statusOpen : s.statusUpcoming) }}>
                  {c.status === 'open' ? 'Buka' : 'Segera'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Latest news */}
      <div style={s.section}>
        <div style={s.sectionHeader}>
          <h2 style={s.sectionTitle}>Berita & Fakta Terbaru</h2>
          <button style={s.seeAll} onClick={() => setPage('news')}>Lihat semua →</button>
        </div>
        <div style={s.newsGrid}>
          {latestNews.map(n => (
            <button key={n.id} onClick={() => setPage('news')} style={s.newsCard}>
              <div style={s.newsIcon}>{n.icon}</div>
              <div>
                <span style={{ ...s.newsCat, ...(n.category === 'Prestasi' ? { color: '#2a7a2a', background: '#e8f8e8' } : { color: '#9a7220', background: '#fdf3dc' }) }}>{n.category}</span>
                <div style={s.newsTitle}>{n.title}</div>
                <div style={s.newsDate}>{n.date} • {n.readTime}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1200, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  welcome: { background: 'linear-gradient(135deg, #4e7a5e, #7a9e87)', borderRadius: 'var(--radius-xl)', padding: '28px 32px', color: 'white', marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 },
  welcomeHi: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(18px, 3vw, 24px)', fontWeight: 600, marginBottom: 6 },
  welcomeSub: { fontSize: 14, opacity: 0.85 },
  streakBox: { display: 'flex', alignItems: 'center', gap: 12, background: 'rgba(255,255,255,0.2)', borderRadius: 14, padding: '12px 20px' },
  streakFire: { fontSize: 32 },
  streakNum: { fontSize: 28, fontWeight: 700, fontFamily: 'var(--font-mono)', lineHeight: 1 },
  streakLbl: { fontSize: 12, opacity: 0.85, marginTop: 2 },
  statsRow: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 16, marginBottom: 28 },
  statCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '20px 16px', textAlign: 'center' },
  statVal: { fontSize: 22, fontWeight: 700, fontFamily: 'var(--font-mono)', marginBottom: 4 },
  statLbl: { fontSize: 13, color: 'var(--muted)' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 360px', gap: 24, marginBottom: 28, '@media(max-width:900px)': { gridTemplateColumns: '1fr' } },
  section: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '22px', marginBottom: 20 },
  sectionHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontFamily: 'var(--font-serif)', fontSize: 18, color: 'var(--ink)' },
  seeAll: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontSize: 13, fontWeight: 500, cursor: 'pointer' },
  materialCards: { display: 'flex', flexDirection: 'column', gap: 10 },
  matCard: { display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', background: 'var(--cream)', border: '1px solid var(--border-light)', borderRadius: 10, cursor: 'pointer', textAlign: 'left', transition: 'background 0.15s' },
  matIcon: { fontSize: 24, width: 36, textAlign: 'center' },
  matTitle: { fontSize: 14, fontWeight: 500, color: 'var(--ink)', marginBottom: 2 },
  matMeta: { fontSize: 12, color: 'var(--muted)' },
  levelPill: { fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 20, whiteSpace: 'nowrap' },
  quickGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 },
  quickBtn: { border: 'none', borderRadius: 12, padding: '16px 12px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, transition: 'transform 0.15s' },
  quickLabel: { fontSize: 13, fontWeight: 600 },
  compItem: { display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: '1px solid var(--border-light)' },
  compName: { fontSize: 13, fontWeight: 500, color: 'var(--ink)', marginBottom: 3 },
  compMeta: { fontSize: 12, color: 'var(--muted)' },
  statusBadge: { fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 20, whiteSpace: 'nowrap' },
  statusOpen: { background: '#e8f8e8', color: '#2a7a2a' },
  statusUpcoming: { background: '#fdf3dc', color: '#9a7220' },
  newsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 },
  newsCard: { background: 'var(--cream)', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-md)', padding: '16px', display: 'flex', gap: 12, cursor: 'pointer', textAlign: 'left', transition: 'background 0.15s' },
  newsIcon: { fontSize: 28, flexShrink: 0 },
  newsCat: { fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 20, display: 'inline-block', marginBottom: 6 },
  newsTitle: { fontSize: 14, fontWeight: 500, color: 'var(--ink)', lineHeight: 1.4, marginBottom: 4 },
  newsDate: { fontSize: 12, color: 'var(--muted)' },
}
