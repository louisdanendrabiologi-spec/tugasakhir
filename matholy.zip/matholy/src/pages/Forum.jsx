import React, { useState } from 'react'
import { forumPosts } from '../data'
import { useApp } from '../context/AppContext'

const TOPICS = ['Semua', 'Umum', 'Aljabar', 'Geometri', 'Kombinatorik', 'Teori Bilangan']

export default function Forum() {
  const { user } = useApp()
  const [posts, setPosts] = useState(forumPosts)
  const [topic, setTopic] = useState('Semua')
  const [selected, setSelected] = useState(null)
  const [newPost, setNewPost] = useState(false)
  const [form, setForm] = useState({ title: '', topic: 'Umum', content: '' })
  const [replyText, setReplyText] = useState('')
  const [replies, setReplies] = useState({})

  const filtered = posts.filter(p => topic === 'Semua' || p.topic === topic)

  const handleSubmitPost = () => {
    if (!form.title || !form.content) return
    const post = {
      id: posts.length + 1, title: form.title, author: user.name, avatar: user.avatar,
      date: new Date().toISOString().slice(0, 10), topic: form.topic,
      replies: 0, views: 1, content: form.content
    }
    setPosts(prev => [post, ...prev])
    setForm({ title: '', topic: 'Umum', content: '' })
    setNewPost(false)
    setSelected(post)
  }

  const handleReply = (postId) => {
    if (!replyText.trim()) return
    const r = { author: user.name, avatar: user.avatar, text: replyText, date: new Date().toISOString().slice(0, 10) }
    setReplies(prev => ({ ...prev, [postId]: [...(prev[postId] || []), r] }))
    setReplyText('')
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, replies: p.replies + 1 } : p))
  }

  const topicColors = { Umum: '#2a7a2a', Aljabar: '#3a5a9a', Geometri: '#9a4e2e', Kombinatorik: '#6a3a9a', 'Teori Bilangan': '#9a7220' }
  const topicBgs = { Umum: '#e8f8e8', Aljabar: '#e8eef8', Geometri: '#faeee8', Kombinatorik: '#f0ebf8', 'Teori Bilangan': '#fdf3dc' }

  if (selected) {
    const postReplies = replies[selected.id] || []
    return (
      <div style={s.wrap}>
        <button onClick={() => setSelected(null)} style={s.back}>← Kembali ke Forum</button>
        <div style={s.threadCard}>
          <div style={s.threadHeader}>
            {selected.pinned && <span style={s.pinBadge}>📌 Disematkan</span>}
            <span style={{ ...s.topicBadge, background: topicBgs[selected.topic], color: topicColors[selected.topic] }}>{selected.topic}</span>
            <h1 style={s.threadTitle}>{selected.title}</h1>
            <div style={s.threadMeta}>
              <span style={s.threadAvatar}>{selected.avatar}</span>
              <span style={s.threadAuthor}>{selected.author}</span>
              <span style={s.threadDate}>{selected.date}</span>
              <span style={s.threadViews}>👁 {selected.views}</span>
            </div>
          </div>
          <div style={s.threadContent}>{selected.content}</div>

          {/* Existing replies */}
          <div style={s.repliesSection}>
            <div style={s.repliesTitle}>{(selected.replies + postReplies.length)} Balasan</div>
            {/* Placeholder replies */}
            {[
              { author: 'Tim MathOly', avatar: '🦅', text: 'Pertanyaan bagus! Ini topik yang sering ditanyakan.', date: selected.date },
            ].concat(postReplies).map((r, i) => (
              <div key={i} style={s.replyItem}>
                <span style={s.replyAvatar}>{r.avatar}</span>
                <div style={s.replyBody}>
                  <div style={s.replyHeader}>
                    <span style={s.replyAuthor}>{r.author}</span>
                    <span style={s.replyDate}>{r.date}</span>
                  </div>
                  <div style={s.replyText}>{r.text}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Reply box */}
          <div style={s.replyBox}>
            <span style={s.replyMeAvatar}>{user?.avatar}</span>
            <div style={{ flex: 1 }}>
              <textarea
                style={s.replyInput}
                placeholder="Tulis balasanmu..."
                rows={3}
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
              />
              <button onClick={() => handleReply(selected.id)} style={s.replyBtn}>Kirim Balasan</button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <div>
          <h1 style={s.title}>Forum Diskusi</h1>
          <p style={s.desc}>Tanya, bahas, dan berbagi strategi bersama sesama pecinta olimpiade matematika.</p>
        </div>
        <button onClick={() => setNewPost(!newPost)} style={s.newPostBtn}>✏️ Buat Diskusi Baru</button>
      </div>

      {/* New post form */}
      {newPost && (
        <div style={s.newPostForm}>
          <h3 style={s.newPostTitle}>Buat Diskusi Baru</h3>
          <input style={s.input} placeholder="Judul diskusi..." value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
          <select style={s.select} value={form.topic} onChange={e => setForm(p => ({ ...p, topic: e.target.value }))}>
            {TOPICS.filter(t => t !== 'Semua').map(t => <option key={t}>{t}</option>)}
          </select>
          <textarea style={s.textarea} placeholder="Tulis pertanyaan atau diskusimu..." rows={4}
            value={form.content} onChange={e => setForm(p => ({ ...p, content: e.target.value }))} />
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={handleSubmitPost} style={s.submitBtn}>Posting</button>
            <button onClick={() => setNewPost(false)} style={s.cancelBtn}>Batal</button>
          </div>
        </div>
      )}

      {/* Topic filter */}
      <div style={s.topicRow}>
        {TOPICS.map(t => (
          <button key={t} onClick={() => setTopic(t)} style={{ ...s.topicBtn, ...(topic === t ? s.topicBtnActive : {}) }}>{t}</button>
        ))}
      </div>

      {/* Posts list */}
      <div style={s.postList}>
        {filtered.map(post => (
          <button key={post.id} onClick={() => setSelected(post)} style={s.postCard}>
            <div style={s.postLeft}>
              {post.pinned && <span style={s.pinIcon}>📌</span>}
              <span style={{ ...s.topicBadge, background: topicBgs[post.topic], color: topicColors[post.topic] }}>{post.topic}</span>
              <h3 style={s.postTitle}>{post.title}</h3>
              <div style={s.postMeta}>
                <span>{post.avatar} {post.author}</span>
                <span>·</span>
                <span>{post.date}</span>
              </div>
            </div>
            <div style={s.postStats}>
              <div style={s.postStat}><div style={s.postStatNum}>{post.replies}</div><div style={s.postStatLbl}>balasan</div></div>
              <div style={s.postStat}><div style={s.postStatNum}>{post.views}</div><div style={s.postStatLbl}>dilihat</div></div>
            </div>
          </button>
        ))}
      </div>

      {filtered.length === 0 && <div style={s.empty}>Belum ada diskusi di topik ini. Jadilah yang pertama!</div>}
    </div>
  )
}

const s = {
  wrap: { maxWidth: 900, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24, flexWrap: 'wrap', gap: 16 },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 6 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  newPostBtn: { background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 10, padding: '10px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap' },
  newPostForm: { background: 'white', border: '1.5px solid var(--sage-light)', borderRadius: 'var(--radius-lg)', padding: '24px', marginBottom: 24, display: 'flex', flexDirection: 'column', gap: 12 },
  newPostTitle: { fontFamily: 'var(--font-serif)', fontSize: 18, color: 'var(--ink)' },
  input: { border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', fontSize: 14, color: 'var(--ink)', background: 'var(--cream)' },
  select: { border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', fontSize: 14, color: 'var(--ink)', background: 'var(--cream)' },
  textarea: { border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', fontSize: 14, color: 'var(--ink)', background: 'var(--cream)', resize: 'vertical', fontFamily: 'var(--font-sans)' },
  submitBtn: { background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 8, padding: '10px 24px', fontSize: 14, fontWeight: 600, cursor: 'pointer' },
  cancelBtn: { background: 'var(--warm-white)', color: 'var(--ink)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 24px', fontSize: 14, cursor: 'pointer' },
  topicRow: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 },
  topicBtn: { padding: '5px 14px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--warm-white)', fontSize: 13, cursor: 'pointer', color: 'var(--ink-light)' },
  topicBtnActive: { background: 'var(--sage-dark)', color: 'white', borderColor: 'var(--sage-dark)', fontWeight: 600 },
  postList: { display: 'flex', flexDirection: 'column', gap: 10 },
  postCard: { background: 'white', border: '1.5px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '18px 20px', cursor: 'pointer', textAlign: 'left', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16, transition: 'all 0.15s' },
  postLeft: { flex: 1, display: 'flex', flexDirection: 'column', gap: 6 },
  pinIcon: { fontSize: 14 },
  topicBadge: { display: 'inline-block', fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20, alignSelf: 'flex-start' },
  postTitle: { fontSize: 15, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.3 },
  postMeta: { display: 'flex', gap: 8, fontSize: 12, color: 'var(--muted)' },
  postStats: { display: 'flex', gap: 20, flexShrink: 0 },
  postStat: { textAlign: 'center' },
  postStatNum: { fontSize: 18, fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--ink)' },
  postStatLbl: { fontSize: 11, color: 'var(--muted)' },
  back: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontSize: 14, cursor: 'pointer', marginBottom: 20, display: 'block' },
  threadCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '32px' },
  threadHeader: { borderBottom: '1px solid var(--border-light)', paddingBottom: 20, marginBottom: 20 },
  pinBadge: { display: 'inline-block', fontSize: 12, color: 'var(--sage-dark)', marginBottom: 8 },
  threadTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(18px, 3vw, 26px)', color: 'var(--ink)', margin: '8px 0 12px' },
  threadMeta: { display: 'flex', gap: 12, alignItems: 'center', fontSize: 13 },
  threadAvatar: { fontSize: 20 },
  threadAuthor: { fontWeight: 600, color: 'var(--ink)' },
  threadDate: { color: 'var(--muted)' },
  threadViews: { color: 'var(--muted)', marginLeft: 'auto' },
  threadContent: { fontSize: 15, color: 'var(--ink-light)', lineHeight: 1.75, marginBottom: 28, fontFamily: 'var(--font-serif)' },
  repliesSection: { borderTop: '1px solid var(--border-light)', paddingTop: 20, marginBottom: 20 },
  repliesTitle: { fontSize: 14, fontWeight: 700, color: 'var(--muted)', marginBottom: 16, textTransform: 'uppercase', letterSpacing: 0.5 },
  replyItem: { display: 'flex', gap: 12, marginBottom: 16 },
  replyAvatar: { fontSize: 24, flexShrink: 0 },
  replyBody: { flex: 1, background: 'var(--warm-white)', borderRadius: 10, padding: '12px 14px' },
  replyHeader: { display: 'flex', gap: 10, marginBottom: 6 },
  replyAuthor: { fontWeight: 600, fontSize: 13, color: 'var(--ink)' },
  replyDate: { fontSize: 12, color: 'var(--muted)' },
  replyText: { fontSize: 14, color: 'var(--ink-light)', lineHeight: 1.6 },
  replyBox: { display: 'flex', gap: 12, alignItems: 'flex-start', borderTop: '1px solid var(--border-light)', paddingTop: 20 },
  replyMeAvatar: { fontSize: 24, flexShrink: 0 },
  replyInput: { width: '100%', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 12px', fontSize: 14, fontFamily: 'var(--font-sans)', color: 'var(--ink)', background: 'var(--cream)', resize: 'vertical', display: 'block', marginBottom: 10, boxSizing: 'border-box' },
  replyBtn: { background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 8, padding: '10px 24px', fontSize: 14, fontWeight: 600, cursor: 'pointer' },
  empty: { textAlign: 'center', padding: 60, color: 'var(--muted)' },
}
