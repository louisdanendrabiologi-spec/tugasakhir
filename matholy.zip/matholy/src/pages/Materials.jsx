import React, { useState } from 'react'
import { materials } from '../data'
import { useApp } from '../context/AppContext'

const LEVELS = ['all', 'beginner', 'intermediate', 'advanced', 'olympiad', 'imo']
const TOPICS = ['Semua', 'Aljabar', 'Geometri', 'Kombinatorik', 'Teori Bilangan']

const levelInfo = {
  beginner: { label: 'Pemula', color: '#2a7a2a', bg: '#e8f8e8' },
  intermediate: { label: 'Menengah', color: '#9a7220', bg: '#fdf3dc' },
  advanced: { label: 'Lanjutan', color: '#9a4e2e', bg: '#faeee8' },
  olympiad: { label: 'Olimpiade', color: '#6a3a9a', bg: '#f0ebf8' },
  imo: { label: 'IMO', color: '#c4a020', bg: '#2c2825' },
}

export default function Materials() {
  const { addPoints } = useApp()
  const [activeLevel, setActiveLevel] = useState('all')
  const [activeTopic, setActiveTopic] = useState('Semua')
  const [selected, setSelected] = useState(null)
  const [completed, setCompleted] = useState(new Set())

  const filtered = materials.filter(m =>
    (activeLevel === 'all' || m.level === activeLevel) &&
    (activeTopic === 'Semua' || m.topic === activeTopic)
  )

  const handleComplete = (m) => {
    if (!completed.has(m.id)) {
      setCompleted(prev => new Set([...prev, m.id]))
      addPoints(m.xp)
    }
    setSelected(null)
  }

  if (selected) {
    const li = levelInfo[selected.level]
    return (
      <div style={s.wrap}>
        <button onClick={() => setSelected(null)} style={s.backBtn}>← Kembali ke Materi</button>
        <div style={s.matDetail}>
          <div style={s.detailHeader}>
            <span style={s.detailIcon}>{selected.icon}</span>
            <div>
              <span style={{ ...s.levelChip, background: li.bg, color: li.color }}>{li.label}</span>
              <h1 style={s.detailTitle}>{selected.title}</h1>
              <div style={s.detailMeta}>{selected.topic} • {selected.duration} • +{selected.xp} XP</div>
            </div>
          </div>
          <div style={s.detailContent}>
            {selected.content.length === 0 ? (
              <div style={s.coming}>📖 Materi lengkap segera hadir. Tetap semangat!</div>
            ) : selected.content.map((block, i) => (
              <div key={i} style={s.block}>
                {block.type === 'text' && <p style={s.textBlock}>{block.text}</p>}
                {block.type === 'formula' && (
                  <div style={s.formulaBlock}>
                    <span style={s.formulaPrefix}>Formula</span>
                    <code style={s.formulaCode}>{block.text}</code>
                  </div>
                )}
                {block.type === 'example' && (
                  <div style={s.exampleBlock}>
                    <div style={s.exampleTitle}>{block.title}</div>
                    <pre style={s.exampleText}>{block.text}</pre>
                  </div>
                )}
              </div>
            ))}
          </div>
          <button
            onClick={() => handleComplete(selected)}
            style={{ ...s.completeBtn, ...(completed.has(selected.id) ? s.completedBtn : {}) }}
          >
            {completed.has(selected.id) ? '✅ Selesai! (+' + selected.xp + ' XP)' : 'Tandai Selesai & Kumpulkan XP →'}
          </button>
        </div>
      </div>
    )
  }

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.pageTitle}>Materi Pembelajaran</h1>
        <p style={s.pageDesc}>Belajar bertahap dari fondasi hingga teknik IMO. Pilih level dan topik yang ingin dipelajari.</p>
      </div>

      {/* Level filter */}
      <div style={s.levelTabs}>
        {LEVELS.map(l => (
          <button key={l} onClick={() => setActiveLevel(l)}
            style={{ ...s.levelTab, ...(activeLevel === l ? (l === 'all' ? s.levelTabActiveAll : { background: levelInfo[l]?.bg, color: levelInfo[l]?.color, border: `1.5px solid ${levelInfo[l]?.color}33` }) : {}) }}>
            {l === 'all' ? 'Semua Level' : levelInfo[l]?.label}
          </button>
        ))}
      </div>

      {/* Topic filter */}
      <div style={s.topicRow}>
        {TOPICS.map(t => (
          <button key={t} onClick={() => setActiveTopic(t)}
            style={{ ...s.topicBtn, ...(activeTopic === t ? s.topicBtnActive : {}) }}>
            {t}
          </button>
        ))}
      </div>

      {/* Materials grid */}
      <div style={s.grid}>
        {filtered.map(m => {
          const li = levelInfo[m.level]
          const done = completed.has(m.id)
          return (
            <button key={m.id} onClick={() => setSelected(m)} style={{ ...s.card, ...(done ? s.cardDone : {}) }}>
              <div style={s.cardTop}>
                <span style={s.cardIcon}>{m.icon}</span>
                <span style={{ ...s.cardLevel, background: li.bg, color: li.color }}>{li.label}</span>
                {done && <span style={s.doneCheck}>✅</span>}
              </div>
              <div style={s.cardTitle}>{m.title}</div>
              <div style={s.cardDesc}>{m.desc}</div>
              <div style={s.cardFooter}>
                <span style={s.cardTopic}>{m.topic}</span>
                <span style={s.cardXP}>+{m.xp} XP</span>
              </div>
              <div style={s.cardDuration}>⏱ {m.duration}</div>
            </button>
          )
        })}
      </div>

      {filtered.length === 0 && (
        <div style={s.empty}>Tidak ada materi untuk filter ini.</div>
      )}
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1200, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 28 },
  pageTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  pageDesc: { color: 'var(--muted)', fontSize: 15 },
  levelTabs: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 },
  levelTab: { padding: '7px 18px', borderRadius: 20, border: '1.5px solid var(--border)', background: 'white', fontSize: 13.5, fontWeight: 500, cursor: 'pointer', transition: 'all 0.15s', color: 'var(--ink-light)' },
  levelTabActiveAll: { background: 'var(--sage-dark)', color: 'white', border: '1.5px solid var(--sage-dark)' },
  topicRow: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 },
  topicBtn: { padding: '5px 14px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--warm-white)', fontSize: 13, cursor: 'pointer', color: 'var(--ink-light)' },
  topicBtnActive: { background: 'var(--parchment)', color: 'var(--ink)', borderColor: 'var(--sand)', fontWeight: 600 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 20 },
  card: { background: 'white', border: '1.5px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '22px 20px', textAlign: 'left', cursor: 'pointer', transition: 'transform 0.2s, box-shadow 0.2s', display: 'flex', flexDirection: 'column', gap: 8 },
  cardDone: { background: 'var(--warm-white)', borderColor: 'var(--sage-light)' },
  cardTop: { display: 'flex', alignItems: 'center', gap: 8 },
  cardIcon: { fontSize: 28 },
  cardLevel: { fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 20 },
  doneCheck: { marginLeft: 'auto', fontSize: 18 },
  cardTitle: { fontFamily: 'var(--font-serif)', fontSize: 16, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.3 },
  cardDesc: { fontSize: 13, color: 'var(--muted)', lineHeight: 1.5, flex: 1 },
  cardFooter: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  cardTopic: { fontSize: 12, color: 'var(--sage-dark)', fontWeight: 500 },
  cardXP: { fontSize: 12, fontWeight: 700, color: 'var(--amber)', fontFamily: 'var(--font-mono)' },
  cardDuration: { fontSize: 12, color: 'var(--muted-light)' },
  empty: { textAlign: 'center', padding: 60, color: 'var(--muted)' },
  backBtn: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontSize: 14, cursor: 'pointer', marginBottom: 20, display: 'block' },
  matDetail: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '32px' },
  detailHeader: { display: 'flex', gap: 20, alignItems: 'flex-start', marginBottom: 28, borderBottom: '1px solid var(--border-light)', paddingBottom: 24 },
  detailIcon: { fontSize: 48, flexShrink: 0 },
  levelChip: { fontSize: 11, fontWeight: 700, padding: '3px 12px', borderRadius: 20, display: 'inline-block', marginBottom: 8 },
  detailTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(20px, 3vw, 28px)', color: 'var(--ink)', marginBottom: 6 },
  detailMeta: { fontSize: 13, color: 'var(--muted)' },
  detailContent: { marginBottom: 28 },
  block: { marginBottom: 16 },
  textBlock: { fontSize: 15, color: 'var(--ink-light)', lineHeight: 1.75 },
  formulaBlock: { background: 'var(--warm-white)', border: '1px solid var(--border)', borderLeft: '3px solid var(--sage)', borderRadius: '0 8px 8px 0', padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 4 },
  formulaPrefix: { fontSize: 10, fontWeight: 700, color: 'var(--sage-dark)', textTransform: 'uppercase', letterSpacing: 1 },
  formulaCode: { fontFamily: 'var(--font-mono)', fontSize: 15, color: 'var(--ink)' },
  exampleBlock: { background: '#fdf8f0', border: '1px solid #e8d8b0', borderRadius: 10, padding: '16px' },
  exampleTitle: { fontSize: 12, fontWeight: 700, color: '#9a7220', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 },
  exampleText: { fontSize: 14, color: 'var(--ink)', fontFamily: 'var(--font-mono)', whiteSpace: 'pre-wrap', lineHeight: 1.6 },
  coming: { textAlign: 'center', padding: '40px 20px', color: 'var(--muted)', fontSize: 16 },
  completeBtn: { background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 12, padding: '14px 28px', fontSize: 15, fontWeight: 600, cursor: 'pointer', width: '100%' },
  completedBtn: { background: 'var(--parchment)', color: 'var(--sage-dark)', cursor: 'default' },
}
