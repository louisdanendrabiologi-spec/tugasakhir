import React, { useState } from 'react'
import { competitions } from '../data'

const statusStyle = {
  open: { bg: '#e8f8e8', color: '#2a7a2a', label: '🟢 Pendaftaran Buka' },
  upcoming: { bg: '#fdf3dc', color: '#9a7220', label: '🟡 Segera Dibuka' },
  closed: { bg: '#f0f0f0', color: '#888', label: '⚫ Ditutup' },
}

const typeStyle = {
  Nasional: { bg: '#e8eef8', color: '#3a5a9a' },
  Internasional: { bg: '#f0ebf8', color: '#6a3a9a' },
  Tim: { bg: '#faeee8', color: '#9a4e2e' },
  Sekolah: { bg: '#e8f8e8', color: '#2a7a2a' },
}

export default function Competitions() {
  const [filter, setFilter] = useState('Semua')
  const [selected, setSelected] = useState(null)

  const types = ['Semua', 'Nasional', 'Internasional', 'Tim', 'Sekolah']
  const filtered = competitions.filter(c => filter === 'Semua' || c.type === filter)

  if (selected) return (
    <div style={s.wrap}>
      <button onClick={() => setSelected(null)} style={s.back}>← Kembali</button>
      <div style={s.detailCard}>
        <div style={s.detailTop}>
          <div>
            <div style={s.detailMeta}>
              <span style={{ ...s.typeBadge, background: typeStyle[selected.type]?.bg, color: typeStyle[selected.type]?.color }}>{selected.type}</span>
              <span style={{ ...s.statusLabel, background: statusStyle[selected.status]?.bg, color: statusStyle[selected.status]?.color }}>{statusStyle[selected.status]?.label}</span>
            </div>
            <h1 style={s.detailTitle}>{selected.name}</h1>
            <div style={s.detailOrg}>Penyelenggara: {selected.organizer}</div>
          </div>
        </div>
        <p style={s.detailDesc}>{selected.desc}</p>
        <div style={s.infoGrid}>
          <div style={s.infoItem}><div style={s.infoLabel}>Tanggal</div><div style={s.infoVal}>📅 {selected.date}</div></div>
          <div style={s.infoItem}><div style={s.infoLabel}>Batas Daftar</div><div style={s.infoVal}>⏰ {selected.deadline}</div></div>
          <div style={s.infoItem}><div style={s.infoLabel}>Jenjang</div><div style={s.infoVal}>🎓 {selected.level}</div></div>
          <div style={s.infoItem}><div style={s.infoLabel}>Hadiah</div><div style={s.infoVal}>🏆 {selected.prize}</div></div>
        </div>
        {selected.status === 'open' && (
          <button style={s.registerBtn} onClick={() => alert('Pendaftaran akan diarahkan ke website resmi penyelenggara.')}>
            Daftar Sekarang →
          </button>
        )}
        {selected.status === 'upcoming' && (
          <button style={s.notifyBtn} onClick={() => alert('Kamu akan mendapat notifikasi ketika pendaftaran dibuka!')}>
            🔔 Ingatkan Saya
          </button>
        )}
      </div>
    </div>
  )

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.title}>Info Kompetisi & Lomba</h1>
        <p style={s.desc}>Semua jadwal kompetisi matematika dari tingkat sekolah hingga internasional.</p>
      </div>

      <div style={s.filterRow}>
        {types.map(t => (
          <button key={t} onClick={() => setFilter(t)} style={{ ...s.filterBtn, ...(filter === t ? s.filterBtnActive : {}) }}>{t}</button>
        ))}
      </div>

      <div style={s.grid}>
        {filtered.map(c => {
          const st = statusStyle[c.status]
          const ty = typeStyle[c.type] || {}
          return (
            <button key={c.id} onClick={() => setSelected(c)} style={s.compCard}>
              <div style={s.compTop}>
                <span style={{ ...s.typeBadge, background: ty.bg, color: ty.color }}>{c.type}</span>
                <span style={{ ...s.statusLabel, background: st.bg, color: st.color }}>{st.label}</span>
              </div>
              <h3 style={s.compName}>{c.name}</h3>
              <div style={s.compOrg}>{c.organizer}</div>
              <p style={s.compDesc}>{c.desc}</p>
              <div style={s.compFooter}>
                <span style={s.compDate}>📅 {c.date}</span>
                <span style={s.compLevel}>🎓 {c.level}</span>
              </div>
              <div style={s.compPrize}>🏆 {c.prize}</div>
            </button>
          )
        })}
      </div>

      {filtered.length === 0 && <div style={s.empty}>Belum ada kompetisi di kategori ini.</div>}
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1200, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 24 },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  filterRow: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 },
  filterBtn: { padding: '7px 18px', borderRadius: 20, border: '1px solid var(--border)', background: 'white', fontSize: 13, cursor: 'pointer', color: 'var(--ink-light)' },
  filterBtnActive: { background: 'var(--sage-dark)', color: 'white', borderColor: 'var(--sage-dark)', fontWeight: 600 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 20 },
  compCard: { background: 'white', border: '1.5px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '22px', cursor: 'pointer', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 8, transition: 'all 0.15s' },
  compTop: { display: 'flex', gap: 8, flexWrap: 'wrap' },
  typeBadge: { fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20 },
  statusLabel: { fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 20 },
  compName: { fontFamily: 'var(--font-serif)', fontSize: 16, color: 'var(--ink)', lineHeight: 1.3, fontWeight: 600 },
  compOrg: { fontSize: 12, color: 'var(--muted)' },
  compDesc: { fontSize: 13, color: 'var(--ink-light)', lineHeight: 1.5, flex: 1 },
  compFooter: { display: 'flex', gap: 16, fontSize: 12, color: 'var(--muted)' },
  compDate: {},
  compLevel: {},
  compPrize: { fontSize: 12, color: 'var(--sage-dark)', fontWeight: 500 },
  back: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontSize: 14, cursor: 'pointer', marginBottom: 20, display: 'block' },
  detailCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '36px', maxWidth: 800 },
  detailTop: { marginBottom: 20 },
  detailMeta: { display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' },
  detailTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(20px, 3vw, 28px)', color: 'var(--ink)', marginBottom: 6 },
  detailOrg: { fontSize: 13, color: 'var(--muted)' },
  detailDesc: { fontSize: 15, color: 'var(--ink-light)', lineHeight: 1.7, marginBottom: 24 },
  infoGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 },
  infoItem: { background: 'var(--warm-white)', border: '1px solid var(--border-light)', borderRadius: 10, padding: '14px' },
  infoLabel: { fontSize: 11, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
  infoVal: { fontSize: 14, fontWeight: 600, color: 'var(--ink)' },
  registerBtn: { background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 12, padding: '14px 32px', fontSize: 15, fontWeight: 600, cursor: 'pointer' },
  notifyBtn: { background: 'var(--warm-white)', color: 'var(--ink)', border: '1px solid var(--border)', borderRadius: 12, padding: '14px 32px', fontSize: 15, fontWeight: 500, cursor: 'pointer' },
  empty: { textAlign: 'center', padding: 60, color: 'var(--muted)' },
}
