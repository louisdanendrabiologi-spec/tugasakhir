import React, { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function Landing() {
  const { login, register } = useApp()
  const [mode, setMode] = useState('landing') // landing | login | register
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')

  const handleLogin = () => {
    if (!login(form.email, form.password)) setError('Email atau password salah.')
  }

  const handleRegister = () => {
    if (!form.name || !form.email || !form.password) { setError('Semua kolom wajib diisi.'); return }
    if (!register(form.name, form.email, form.password)) setError('Email sudah terdaftar.')
  }

  const update = (k, v) => { setForm(p => ({ ...p, [k]: v })); setError('') }

  if (mode === 'login' || mode === 'register') {
    return (
      <div style={s.authBg}>
        <div style={s.authCard}>
          <button onClick={() => setMode('landing')} style={s.backBtn}>← Kembali</button>
          <div style={s.authLogo}>
            <span style={s.authLogoMath}>∑</span>
            <span style={s.authLogoText}>MathOly</span>
          </div>
          <h2 style={s.authTitle}>{mode === 'login' ? 'Masuk ke Akun' : 'Buat Akun Baru'}</h2>
          {mode === 'register' && (
            <input style={s.input} placeholder="Nama lengkap" value={form.name}
              onChange={e => update('name', e.target.value)} />
          )}
          <input style={s.input} placeholder="Email" type="email" value={form.email}
            onChange={e => update('email', e.target.value)} />
          <input style={s.input} placeholder="Password" type="password" value={form.password}
            onChange={e => update('password', e.target.value)}
            onKeyDown={e => e.key === 'Enter' && (mode === 'login' ? handleLogin() : handleRegister())} />
          {error && <div style={s.error}>{error}</div>}
          <button style={s.primaryBtn} onClick={mode === 'login' ? handleLogin : handleRegister}>
            {mode === 'login' ? 'Masuk' : 'Daftar Sekarang'}
          </button>
          {mode === 'login' && (
            <div style={s.hint}>Demo: budi@mail.com / 1234</div>
          )}
          <div style={s.switchMode}>
            {mode === 'login' ? 'Belum punya akun?' : 'Sudah punya akun?'}
            <button style={s.switchBtn} onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError('') }}>
              {mode === 'login' ? 'Daftar' : 'Masuk'}
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={s.landingBg}>
      {/* Hero */}
      <div style={s.hero}>
        <div style={s.heroDecor}>∑ π √ ∫ ∞ ∂ ∇ ∏</div>
        <div style={s.heroContent}>
          <div style={s.badge}>Platform Olimpiade Matematika Indonesia</div>
          <h1 style={s.heroTitle}>
            Belajar Matematika<br />
            <span style={s.heroAccent}>dari OSN hingga IMO</span>
          </h1>
          <p style={s.heroDesc}>
            Materi bertahap dari pemula hingga IMO, kuis interaktif, soal dari seluruh dunia, 
            forum diskusi, berita olimpiade, dan bersaing di papan peringkat bulanan.
          </p>
          <div style={s.heroBtns}>
            <button style={s.ctaBtn} onClick={() => setMode('register')}>Mulai Belajar Gratis →</button>
            <button style={s.ctaSecondary} onClick={() => setMode('login')}>Sudah Punya Akun</button>
          </div>
        </div>
        <div style={s.heroSymbols}>
          {['∑', 'π', '∫', '√∞', '∂', '∇'].map((sym, i) => (
            <div key={i} style={{ ...s.floatSymbol, animationDelay: `${i * 0.4}s`, top: `${15 + (i % 3) * 25}%`, left: `${10 + i * 15}%` }}>{sym}</div>
          ))}
        </div>
      </div>

      {/* Features */}
      <div style={s.features}>
        <div style={s.sectionTitle}>Semua yang Kamu Butuhkan</div>
        <div style={s.featureGrid}>
          {[
            { icon: '📚', title: 'Materi Bertahap', desc: 'Dari penjumlahan dasar hingga teknik IMO. 5 level: Pemula, Menengah, Lanjutan, Olimpiade, IMO.' },
            { icon: '✏️', title: 'Kuis Interaktif', desc: 'Ratusan soal dengan XP, hint, dan pembahasan. Kumpulkan poin dan naiki peringkat!' },
            { icon: '🧩', title: 'Bank Soal Lengkap', desc: 'Soal dari SD hingga IMO, dari Indonesia & mancanegara. OSN, AIME, Kangaroo, IMO Shortlist.' },
            { icon: '📄', title: 'Referensi PDF', desc: 'ABTJOG, AGMO, IMO Compendium, Olympiad Combinatorics — semua tersedia.' },
            { icon: '🏆', title: 'Peringkat Bulanan', desc: 'Bersaing di leaderboard, menangkan lencana, dan jadilah yang terbaik bulan ini!' },
            { icon: '💬', title: 'Forum Diskusi', desc: 'Tanya, bahas, dan berbagi strategi bersama sesama pecinta matematika.' },
            { icon: '📰', title: 'Berita & Fakta', desc: 'Update prestasi Indonesia, jadwal kompetisi, dan fakta menarik seputar olimpiade.' },
            { icon: '🎯', title: 'Info Lomba', desc: 'Jangan lewatkan kompetisi! Semua jadwal dan pendaftaran ada di sini.' },
          ].map((f, i) => (
            <div key={i} style={s.featureCard}>
              <div style={s.featureIcon}>{f.icon}</div>
              <div style={s.featureTitle}>{f.title}</div>
              <div style={s.featureDesc}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Levels */}
      <div style={s.levels}>
        <div style={s.sectionTitle}>5 Level Pembelajaran</div>
        <div style={s.levelRow}>
          {[
            { label: 'Pemula', color: '#2a7a2a', bg: '#e8f8e8', desc: 'Aritmetika, geometri dasar, FPB/KPK' },
            { label: 'Menengah', color: '#9a7220', bg: '#fdf3dc', desc: 'Kombinatorik, modular aritmetika' },
            { label: 'Lanjutan', color: '#9a4e2e', bg: '#faeee8', desc: 'PIE, geometri proyektif, pertidaksamaan' },
            { label: 'Olimpiade', color: '#6a3a9a', bg: '#f0ebf8', desc: 'Level OSN/APMO/AIME' },
            { label: 'IMO', color: '#c4a020', bg: '#2c2825', desc: 'Teknik pembuktian level dunia' },
          ].map((l, i) => (
            <div key={i} style={{ ...s.levelCard, background: l.bg }}>
              <div style={{ ...s.levelNum, color: l.color }}>{i + 1}</div>
              <div style={{ ...s.levelLabel, color: l.color }}>{l.label}</div>
              <div style={s.levelDesc}>{l.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Footer */}
      <div style={s.ctaSection}>
        <h2 style={s.ctaTitle}>Siap Menjadi Juara Olimpiade?</h2>
        <button style={s.ctaBtn} onClick={() => setMode('register')}>Daftar Sekarang — Gratis!</button>
      </div>
    </div>
  )
}

const s = {
  landingBg: { minHeight: '100vh', background: 'var(--cream)' },
  hero: { position: 'relative', overflow: 'hidden', padding: '80px 20px 100px', maxWidth: 1200, margin: '0 auto', textAlign: 'center' },
  heroDecor: { position: 'absolute', top: 20, left: '50%', transform: 'translateX(-50%)', fontSize: 13, color: 'var(--muted-light)', letterSpacing: 8, fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap' },
  heroContent: { position: 'relative', zIndex: 2 },
  badge: { display: 'inline-block', background: 'var(--warm-white)', border: '1px solid var(--border)', borderRadius: 20, padding: '6px 18px', fontSize: 13, color: 'var(--sage-dark)', fontWeight: 500, marginBottom: 24 },
  heroTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(36px, 6vw, 64px)', lineHeight: 1.2, color: 'var(--ink)', marginBottom: 20 },
  heroAccent: { color: 'var(--sage-dark)' },
  heroDesc: { fontSize: 'clamp(15px, 2vw, 18px)', color: 'var(--ink-light)', maxWidth: 560, margin: '0 auto 36px', lineHeight: 1.7 },
  heroBtns: { display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' },
  ctaBtn: { background: 'var(--sage-dark)', color: 'white', padding: '14px 32px', borderRadius: 12, fontSize: 16, fontWeight: 600, cursor: 'pointer', border: 'none', transition: 'transform 0.15s' },
  ctaSecondary: { background: 'white', color: 'var(--ink)', padding: '14px 32px', borderRadius: 12, fontSize: 16, fontWeight: 500, cursor: 'pointer', border: '1px solid var(--border)' },
  heroSymbols: { position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 1 },
  floatSymbol: { position: 'absolute', fontFamily: 'var(--font-serif)', fontSize: 32, color: 'rgba(122,158,135,0.12)', animation: 'float 4s ease-in-out infinite' },
  features: { padding: '60px 20px', maxWidth: 1200, margin: '0 auto' },
  sectionTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', textAlign: 'center', marginBottom: 40, color: 'var(--ink)' },
  featureGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 20 },
  featureCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '24px 20px', transition: 'transform 0.2s, box-shadow 0.2s' },
  featureIcon: { fontSize: 32, marginBottom: 12 },
  featureTitle: { fontWeight: 600, fontSize: 16, marginBottom: 8, color: 'var(--ink)' },
  featureDesc: { fontSize: 14, color: 'var(--muted)', lineHeight: 1.6 },
  levels: { background: 'var(--warm-white)', padding: '60px 20px', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' },
  levelRow: { display: 'flex', gap: 16, maxWidth: 1200, margin: '0 auto', flexWrap: 'wrap', justifyContent: 'center' },
  levelCard: { flex: '1 1 160px', borderRadius: 'var(--radius-lg)', padding: '24px 16px', textAlign: 'center', maxWidth: 200 },
  levelNum: { fontSize: 32, fontFamily: 'var(--font-mono)', fontWeight: 700, marginBottom: 4 },
  levelLabel: { fontWeight: 700, fontSize: 16, marginBottom: 8 },
  levelDesc: { fontSize: 12, color: 'var(--muted)', lineHeight: 1.5 },
  ctaSection: { padding: '80px 20px', textAlign: 'center', background: 'var(--cream)' },
  ctaTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 40px)', marginBottom: 24, color: 'var(--ink)' },
  authBg: { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--warm-white)', padding: 20 },
  authCard: { background: 'white', borderRadius: 'var(--radius-xl)', border: '1px solid var(--border)', padding: '40px 36px', width: '100%', maxWidth: 400, boxShadow: 'var(--shadow-large)' },
  backBtn: { background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 14, marginBottom: 24, display: 'block' },
  authLogo: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 24 },
  authLogoMath: { fontFamily: 'var(--font-serif)', fontSize: 28, color: 'var(--sage-dark)' },
  authLogoText: { fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 700 },
  authTitle: { fontFamily: 'var(--font-serif)', fontSize: 22, marginBottom: 20 },
  input: { width: '100%', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 14px', fontSize: 15, marginBottom: 12, background: 'var(--cream)', color: 'var(--ink)', display: 'block', boxSizing: 'border-box' },
  error: { color: '#c44', fontSize: 13, marginBottom: 12, background: '#fff0f0', padding: '8px 12px', borderRadius: 8 },
  primaryBtn: { width: '100%', background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 10, padding: '13px 0', fontSize: 15, fontWeight: 600, cursor: 'pointer', marginBottom: 12 },
  hint: { fontSize: 12, color: 'var(--muted)', textAlign: 'center', marginBottom: 12, fontFamily: 'var(--font-mono)' },
  switchMode: { textAlign: 'center', fontSize: 14, color: 'var(--muted)' },
  switchBtn: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontWeight: 600, cursor: 'pointer', fontSize: 14, marginLeft: 4 },
}
