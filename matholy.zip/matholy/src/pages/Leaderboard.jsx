import React, { useState } from 'react'
import { useApp } from '../context/AppContext'

const MONTHS = ['Januari 2025', 'Februari 2025', 'Maret 2025', 'April 2025']
const BADGES_INFO = [
  { icon: '🥇', name: 'Juara Bulan', desc: 'Peringkat #1 di bulan ini' },
  { icon: '🥈', name: 'Runner-Up', desc: 'Peringkat #2 di bulan ini' },
  { icon: '🥉', name: 'Podium', desc: 'Peringkat #3 di bulan ini' },
  { icon: '🔥', name: 'On Fire', desc: 'Streak belajar 7+ hari' },
  { icon: '⚡', name: 'Lightning', desc: '100 soal benar dalam sehari' },
  { icon: '📚', name: 'Scholar', desc: 'Selesaikan 5 materi' },
]

export default function Leaderboard() {
  const { users, user } = useApp()
  const [month, setMonth] = useState(MONTHS[3])

  const ranked = [...users].sort((a, b) => b.points - a.points)

  const medalFor = (rank) => {
    if (rank === 0) return '🥇'
    if (rank === 1) return '🥈'
    if (rank === 2) return '🥉'
    return null
  }

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.title}>Papan Peringkat Bulanan</h1>
        <p style={s.desc}>Bersaing, kumpulkan poin, dan menangkan lencana eksklusif setiap bulan!</p>
      </div>

      {/* Month selector */}
      <div style={s.monthRow}>
        {MONTHS.map(m => (
          <button key={m} onClick={() => setMonth(m)} style={{ ...s.monthBtn, ...(month === m ? s.monthBtnActive : {}) }}>{m}</button>
        ))}
      </div>

      <div style={s.layout}>
        {/* Podium */}
        <div style={s.main}>
          <div style={s.podiumSection}>
            <h2 style={s.podTitle}>🏆 Podium {month}</h2>
            <div style={s.podium}>
              {ranked.slice(0, 3).map((u, i) => (
                <div key={u.id} style={{ ...s.podCard, ...(i === 0 ? s.pod1 : i === 1 ? s.pod2 : s.pod3) }}>
                  <div style={s.podMedal}>{medalFor(i)}</div>
                  <div style={s.podRank}>#{i + 1}</div>
                  <div style={s.podAvatar}>{u.avatar}</div>
                  <div style={s.podName}>{u.name.split(' ')[0]}</div>
                  <div style={s.podPoints}>{u.points.toLocaleString()}</div>
                  <div style={s.podPtsLabel}>poin</div>
                </div>
              ))}
            </div>
          </div>

          {/* Full ranking */}
          <div style={s.rankTable}>
            <div style={s.rankHeader}>
              <span style={{ width: 40 }}>#</span>
              <span style={{ flex: 1 }}>Pengguna</span>
              <span>Streak</span>
              <span>Lencana</span>
              <span style={{ textAlign: 'right' }}>Poin</span>
            </div>
            {ranked.map((u, i) => {
              const isMe = user && u.id === user.id
              return (
                <div key={u.id} style={{ ...s.rankRow, ...(isMe ? s.rankRowMe : {}) }}>
                  <span style={s.rankNum}>
                    {i < 3 ? medalFor(i) : <span style={s.rankNumText}>{i + 1}</span>}
                  </span>
                  <span style={s.rankUser}>
                    <span style={s.rankAvatar}>{u.avatar}</span>
                    <span>
                      <span style={s.rankName}>{u.name}{isMe && <span style={s.youTag}> Kamu</span>}</span>
                      <span style={s.rankLevel}>{u.level}</span>
                    </span>
                  </span>
                  <span style={s.rankStreak}>🔥 {u.streak}d</span>
                  <span style={s.rankBadges}>{u.badges.slice(0, 3).join(' ')||'—'}</span>
                  <span style={s.rankPoints}>{u.points.toLocaleString()}</span>
                </div>
              )
            })}
          </div>
        </div>

        {/* Side: badges */}
        <div>
          {/* My stats */}
          {user && (
            <div style={s.myCard}>
              <div style={s.myTitle}>Statistikmu</div>
              <div style={s.myAvatar}>{user.avatar}</div>
              <div style={s.myName}>{user.name}</div>
              <div style={s.myRankBig}>#{ranked.findIndex(u => u.id === user.id) + 1}</div>
              <div style={s.myRankLabel}>Peringkat Bulan Ini</div>
              <div style={s.myStats}>
                <div style={s.myStat}><div style={s.myStatNum}>{user.points.toLocaleString()}</div><div style={s.myStatLbl}>Poin</div></div>
                <div style={s.myStat}><div style={s.myStatNum}>{user.streak}</div><div style={s.myStatLbl}>Streak</div></div>
                <div style={s.myStat}><div style={s.myStatNum}>{user.badges.length}</div><div style={s.myStatLbl}>Lencana</div></div>
              </div>
            </div>
          )}

          {/* Badge list */}
          <div style={s.badgesCard}>
            <div style={s.badgesTitle}>🎖️ Semua Lencana</div>
            {BADGES_INFO.map((b, i) => (
              <div key={i} style={s.badgeItem}>
                <span style={s.badgeEmoji}>{b.icon}</span>
                <div>
                  <div style={s.badgeName}>{b.name}</div>
                  <div style={s.badgeDesc}>{b.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1100, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 24 },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  monthRow: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 28 },
  monthBtn: { padding: '7px 18px', borderRadius: 20, border: '1px solid var(--border)', background: 'white', fontSize: 13, cursor: 'pointer', color: 'var(--ink-light)' },
  monthBtnActive: { background: 'var(--sage-dark)', color: 'white', borderColor: 'var(--sage-dark)', fontWeight: 600 },
  layout: { display: 'grid', gridTemplateColumns: '1fr 280px', gap: 24 },
  main: {},
  podiumSection: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '28px', marginBottom: 20 },
  podTitle: { fontFamily: 'var(--font-serif)', fontSize: 20, marginBottom: 24, textAlign: 'center' },
  podium: { display: 'flex', gap: 16, justifyContent: 'center', alignItems: 'flex-end' },
  podCard: { borderRadius: 'var(--radius-lg)', padding: '20px 16px', textAlign: 'center', flex: '0 1 180px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 },
  pod1: { background: 'linear-gradient(160deg, #fdf3dc, #f5e8c0)', border: '2px solid #d4a644', paddingTop: 28 },
  pod2: { background: 'linear-gradient(160deg, #f0f4f8, #dde7f0)', border: '2px solid #a0b4c8' },
  pod3: { background: 'linear-gradient(160deg, #faeee8, #f0ddd4)', border: '2px solid #c4785a' },
  podMedal: { fontSize: 28 },
  podRank: { fontSize: 12, fontWeight: 700, color: 'var(--muted)', letterSpacing: 1 },
  podAvatar: { fontSize: 36, margin: '4px 0' },
  podName: { fontWeight: 700, fontSize: 15, color: 'var(--ink)' },
  podPoints: { fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color: 'var(--sage-dark)' },
  podPtsLabel: { fontSize: 11, color: 'var(--muted)' },
  rankTable: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' },
  rankHeader: { display: 'flex', gap: 12, padding: '12px 20px', background: 'var(--warm-white)', fontSize: 12, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 0.5, borderBottom: '1px solid var(--border-light)' },
  rankRow: { display: 'flex', gap: 12, padding: '14px 20px', alignItems: 'center', borderBottom: '1px solid var(--border-light)', transition: 'background 0.15s' },
  rankRowMe: { background: '#f0f8f2', borderLeft: '3px solid var(--sage-dark)' },
  rankNum: { width: 40, fontSize: 18, flexShrink: 0, textAlign: 'center' },
  rankNumText: { fontSize: 14, fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--muted)' },
  rankUser: { flex: 1, display: 'flex', gap: 10, alignItems: 'center' },
  rankAvatar: { fontSize: 24 },
  rankName: { fontSize: 14, fontWeight: 600, color: 'var(--ink)', display: 'block' },
  rankLevel: { fontSize: 11, color: 'var(--muted)' },
  youTag: { background: 'var(--sage-dark)', color: 'white', fontSize: 10, padding: '2px 6px', borderRadius: 10, marginLeft: 4 },
  rankStreak: { fontSize: 13, color: 'var(--muted)', width: 60, textAlign: 'center' },
  rankBadges: { fontSize: 16, width: 80, textAlign: 'center' },
  rankPoints: { fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: 'var(--sage-dark)', textAlign: 'right', minWidth: 60 },
  myCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '24px', textAlign: 'center', marginBottom: 16 },
  myTitle: { fontSize: 13, fontWeight: 600, color: 'var(--muted)', marginBottom: 12 },
  myAvatar: { fontSize: 48, marginBottom: 8 },
  myName: { fontWeight: 600, fontSize: 15, marginBottom: 8 },
  myRankBig: { fontFamily: 'var(--font-mono)', fontSize: 48, fontWeight: 700, color: 'var(--sage-dark)', lineHeight: 1 },
  myRankLabel: { fontSize: 12, color: 'var(--muted)', marginBottom: 16 },
  myStats: { display: 'flex', borderTop: '1px solid var(--border-light)', paddingTop: 16 },
  myStat: { flex: 1, textAlign: 'center' },
  myStatNum: { fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 700, color: 'var(--ink)' },
  myStatLbl: { fontSize: 11, color: 'var(--muted)', marginTop: 2 },
  badgesCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '20px' },
  badgesTitle: { fontWeight: 600, fontSize: 15, marginBottom: 16, color: 'var(--ink)' },
  badgeItem: { display: 'flex', gap: 12, alignItems: 'center', marginBottom: 14 },
  badgeEmoji: { fontSize: 24, flexShrink: 0 },
  badgeName: { fontSize: 13, fontWeight: 600, color: 'var(--ink)', marginBottom: 2 },
  badgeDesc: { fontSize: 12, color: 'var(--muted)' },
}
