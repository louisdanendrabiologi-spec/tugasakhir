import React, { useState } from 'react'
import { pdfResources } from '../data'

const LEVELS = ['Semua', 'SMP', 'SMA', 'Advanced-IMO', 'SMA-IMO', 'Intermediate-Advanced', 'IMO']
const TOPICS = ['Semua', 'Teori Bilangan', 'Kombinatorik', 'Geometri', 'Aljabar', 'Semua Topik']

export default function PDFs() {
  const [topic, setTopic] = useState('Semua')
  const [search, setSearch] = useState('')

  const filtered = pdfResources.filter(p =>
    (topic === 'Semua' || p.topic === topic) &&
    (search === '' || p.title.toLowerCase().includes(search.toLowerCase()) || p.author.toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.title}>Referensi & Materi PDF</h1>
        <p style={s.desc}>Kumpulan buku dan materi olimpiade terlengkap — dari OSN Indonesia hingga persiapan IMO.</p>
      </div>

      <div style={s.searchWrap}>
        <span style={s.searchIcon}>🔍</span>
        <input style={s.search} placeholder="Cari judul atau penulis..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div style={s.topicRow}>
        {TOPICS.map(t => (
          <button key={t} onClick={() => setTopic(t)} style={{ ...s.topicBtn, ...(topic === t ? s.topicActive : {}) }}>{t}</button>
        ))}
      </div>

      <div style={s.grid}>
        {filtered.map(p => (
          <div key={p.id} style={s.card}>
            <div style={s.cardTop}>
              <div style={s.pdfIcon}>📄</div>
              <div style={s.cardMeta}>
                <span style={s.levelBadge}>{p.level}</span>
                <span style={s.topicBadge}>{p.topic}</span>
              </div>
            </div>
            <h3 style={s.cardTitle}>{p.title}</h3>
            <div style={s.cardAuthor}>oleh {p.author} · {p.year}</div>
            <div style={s.cardDesc}>{p.desc}</div>
            <div style={s.cardFooter}>
              <span style={s.pages}>{p.pages} halaman</span>
              <a href={p.url} style={s.downloadBtn} onClick={e => { e.preventDefault(); alert('Fitur unduh akan segera hadir! Hubungi admin untuk akses.') }}>
                Unduh PDF →
              </a>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && <div style={s.empty}>Tidak ada PDF yang sesuai pencarian.</div>}

      {/* Notice */}
      <div style={s.notice}>
        💡 Semua materi PDF disediakan untuk keperluan edukasi non-komersial. Jika ada materi yang kamu miliki dan ingin berbagi, silakan hubungi admin.
      </div>
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1200, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 24 },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  searchWrap: { position: 'relative', marginBottom: 16 },
  searchIcon: { position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 16 },
  search: { width: '100%', border: '1px solid var(--border)', borderRadius: 12, padding: '12px 14px 12px 40px', fontSize: 15, background: 'white', color: 'var(--ink)', boxSizing: 'border-box' },
  topicRow: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 },
  topicBtn: { padding: '5px 14px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--warm-white)', fontSize: 13, cursor: 'pointer', color: 'var(--ink-light)' },
  topicActive: { background: 'var(--sage-dark)', color: 'white', borderColor: 'var(--sage-dark)', fontWeight: 600 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 20, marginBottom: 24 },
  card: { background: 'white', border: '1.5px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '22px 20px', display: 'flex', flexDirection: 'column', gap: 10, transition: 'transform 0.2s, box-shadow 0.2s' },
  cardTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' },
  pdfIcon: { fontSize: 32 },
  cardMeta: { display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'flex-end' },
  levelBadge: { fontSize: 10, background: 'var(--warm-white)', border: '1px solid var(--border)', color: 'var(--muted)', padding: '3px 8px', borderRadius: 20 },
  topicBadge: { fontSize: 10, background: '#e8f2eb', color: 'var(--sage-dark)', padding: '3px 8px', borderRadius: 20, fontWeight: 600 },
  cardTitle: { fontFamily: 'var(--font-serif)', fontSize: 15, color: 'var(--ink)', lineHeight: 1.4, fontWeight: 600 },
  cardAuthor: { fontSize: 12, color: 'var(--muted)' },
  cardDesc: { fontSize: 13, color: 'var(--ink-light)', lineHeight: 1.55, flex: 1 },
  cardFooter: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--border-light)', paddingTop: 12, marginTop: 4 },
  pages: { fontSize: 12, color: 'var(--muted-light)', fontFamily: 'var(--font-mono)' },
  downloadBtn: { background: 'var(--sage-dark)', color: 'white', padding: '7px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' },
  empty: { textAlign: 'center', padding: 60, color: 'var(--muted)' },
  notice: { background: 'var(--warm-white)', border: '1px solid var(--border)', borderRadius: 12, padding: '14px 20px', fontSize: 13, color: 'var(--muted)', lineHeight: 1.6 },
}
