import React, { useState } from 'react'
import { problems } from '../data'

const LEVELS = ['Semua', 'SD', 'SMP', 'SMA', 'IMO']
const SOURCES = ['Semua', 'OSN', 'IMO', 'AIME', 'USAMO', 'Baltic Way', 'Kangaroo Math', 'IMO Shortlist', 'Nasional', 'Internasional']
const TOPICS = ['Semua', 'Aritmetika', 'Aljabar', 'Geometri', 'Kombinatorik', 'Teori Bilangan']

const levelColors = { SD: '#2a7a2a', SMP: '#3a5a9a', SMA: '#9a4e2e', IMO: '#c4a020' }
const levelBgs = { SD: '#e8f8e8', SMP: '#e8eef8', SMA: '#faeee8', IMO: '#fdf8e0' }

export default function Problems() {
  const [level, setLevel] = useState('Semua')
  const [source, setSource] = useState('Semua')
  const [topic, setTopic] = useState('Semua')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const [showAns, setShowAns] = useState(false)

  const filtered = problems.filter(p =>
    (level === 'Semua' || p.level === level) &&
    (source === 'Semua' || p.source === source) &&
    (topic === 'Semua' || p.topic === topic) &&
    (search === '' || p.title.toLowerCase().includes(search.toLowerCase()) || p.problem.toLowerCase().includes(search.toLowerCase()))
  )

  if (selected) return (
    <div style={s.wrap}>
      <button onClick={() => { setSelected(null); setShowAns(false) }} style={s.back}>← Kembali ke Bank Soal</button>
      <div style={s.detailCard}>
        <div style={s.detailMeta}>
          <span style={{ ...s.levelBadge, background: levelBgs[selected.level], color: levelColors[selected.level] }}>{selected.level}</span>
          <span style={s.sourceBadge}>{selected.source}</span>
          <span style={s.topicBadge}>{selected.topic}</span>
          <span style={s.yearBadge}>{selected.year}</span>
          <span style={s.countryBadge}>🌏 {selected.country}</span>
        </div>
        <h2 style={s.detailTitle}>{selected.title}</h2>
        <div style={s.problemBox}>
          <div style={s.problemLabel}>Soal</div>
          <div style={s.problemText}>{selected.problem}</div>
        </div>
        {!showAns ? (
          <button onClick={() => setShowAns(true)} style={s.showAnsBtn}>Tampilkan Jawaban / Petunjuk</button>
        ) : (
          <div style={s.ansBox}>
            <div style={s.ansLabel}>Jawaban / Kunci</div>
            <div style={s.ansText}>{selected.answer}</div>
          </div>
        )}
      </div>
    </div>
  )

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.title}>Bank Soal Olimpiade</h1>
        <p style={s.desc}>Kumpulan soal dari tingkat SD hingga IMO, dari Indonesia dan mancanegara.</p>
      </div>

      {/* Search */}
      <div style={s.searchWrap}>
        <span style={s.searchIcon}>🔍</span>
        <input style={s.search} placeholder="Cari soal..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {/* Filters */}
      <div style={s.filterSection}>
        <div style={s.filterGroup}>
          <span style={s.filterLabel}>Jenjang:</span>
          <div style={s.filterRow}>
            {LEVELS.map(l => <button key={l} onClick={() => setLevel(l)} style={{ ...s.filterBtn, ...(level === l ? s.filterBtnActive : {}) }}>{l}</button>)}
          </div>
        </div>
        <div style={s.filterGroup}>
          <span style={s.filterLabel}>Sumber:</span>
          <div style={s.filterRow}>
            {SOURCES.map(src => <button key={src} onClick={() => setSource(src)} style={{ ...s.filterBtn, ...(source === src ? s.filterBtnActive : {}) }}>{src}</button>)}
          </div>
        </div>
        <div style={s.filterGroup}>
          <span style={s.filterLabel}>Topik:</span>
          <div style={s.filterRow}>
            {TOPICS.map(t => <button key={t} onClick={() => setTopic(t)} style={{ ...s.filterBtn, ...(topic === t ? s.filterBtnActive : {}) }}>{t}</button>)}
          </div>
        </div>
      </div>

      <div style={s.resultCount}>{filtered.length} soal ditemukan</div>

      {/* Problems list */}
      <div style={s.list}>
        {filtered.map(p => (
          <button key={p.id} onClick={() => setSelected(p)} style={s.problemCard}>
            <div style={s.pTop}>
              <span style={{ ...s.levelBadge, background: levelBgs[p.level], color: levelColors[p.level] }}>{p.level}</span>
              <span style={s.sourceBadge}>{p.source}</span>
              <span style={s.topicBadge}>{p.topic}</span>
              <span style={s.countryBadge}>🌏 {p.country}</span>
              <span style={s.yearBadge}>{p.year}</span>
            </div>
            <div style={s.pTitle}>{p.title}</div>
            <div style={s.pPreview}>{p.problem.slice(0, 120)}{p.problem.length > 120 ? '...' : ''}</div>
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <div style={s.empty}>Tidak ada soal yang sesuai filter. Coba ubah filter!</div>
      )}
    </div>
  )
}

const s = {
  wrap: { maxWidth: 1000, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 24 },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  searchWrap: { position: 'relative', marginBottom: 20 },
  searchIcon: { position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 16 },
  search: { width: '100%', border: '1px solid var(--border)', borderRadius: 12, padding: '12px 14px 12px 40px', fontSize: 15, background: 'white', color: 'var(--ink)', boxSizing: 'border-box' },
  filterSection: { display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20, background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: 16 },
  filterGroup: { display: 'flex', gap: 12, alignItems: 'flex-start', flexWrap: 'wrap' },
  filterLabel: { fontSize: 12, fontWeight: 600, color: 'var(--muted)', width: 60, paddingTop: 6, flexShrink: 0 },
  filterRow: { display: 'flex', gap: 6, flexWrap: 'wrap' },
  filterBtn: { padding: '4px 12px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--cream)', fontSize: 12.5, cursor: 'pointer', color: 'var(--ink-light)', fontWeight: 500 },
  filterBtnActive: { background: 'var(--sage-dark)', color: 'white', borderColor: 'var(--sage-dark)' },
  resultCount: { fontSize: 13, color: 'var(--muted)', marginBottom: 16, fontFamily: 'var(--font-mono)' },
  list: { display: 'flex', flexDirection: 'column', gap: 12 },
  problemCard: { background: 'white', border: '1.5px solid var(--border-light)', borderRadius: 'var(--radius-lg)', padding: '18px 20px', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s' },
  pTop: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 },
  levelBadge: { fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20 },
  sourceBadge: { fontSize: 11, background: '#e8eef8', color: '#3a5a9a', padding: '3px 10px', borderRadius: 20, fontWeight: 600 },
  topicBadge: { fontSize: 11, background: 'var(--warm-white)', color: 'var(--muted)', padding: '3px 10px', borderRadius: 20 },
  yearBadge: { fontSize: 11, background: 'var(--parchment)', color: 'var(--muted)', padding: '3px 10px', borderRadius: 20, fontFamily: 'var(--font-mono)' },
  countryBadge: { fontSize: 11, color: 'var(--muted)', padding: '3px 6px' },
  pTitle: { fontWeight: 600, fontSize: 15, color: 'var(--ink)', marginBottom: 6 },
  pPreview: { fontSize: 13, color: 'var(--muted)', lineHeight: 1.5 },
  back: { background: 'none', border: 'none', color: 'var(--sage-dark)', fontSize: 14, cursor: 'pointer', marginBottom: 20, display: 'block' },
  detailCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '32px' },
  detailMeta: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 },
  detailTitle: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(18px, 3vw, 24px)', color: 'var(--ink)', marginBottom: 20 },
  problemBox: { background: 'var(--warm-white)', border: '1px solid var(--border)', borderRadius: 12, padding: '20px', marginBottom: 20 },
  problemLabel: { fontSize: 11, fontWeight: 700, color: 'var(--sage-dark)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 },
  problemText: { fontSize: 15, color: 'var(--ink)', lineHeight: 1.8, fontFamily: 'var(--font-serif)' },
  showAnsBtn: { background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 10, padding: '12px 24px', fontSize: 14, fontWeight: 600, cursor: 'pointer' },
  ansBox: { background: '#e8f8e8', border: '1px solid #a8c4b0', borderRadius: 12, padding: '20px' },
  ansLabel: { fontSize: 11, fontWeight: 700, color: '#2a7a2a', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 },
  ansText: { fontSize: 15, color: 'var(--ink)', lineHeight: 1.7 },
  empty: { textAlign: 'center', padding: 60, color: 'var(--muted)' },
}
