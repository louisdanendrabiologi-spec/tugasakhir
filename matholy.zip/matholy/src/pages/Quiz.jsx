import React, { useState } from 'react'
import { quizData } from '../data'
import { useApp } from '../context/AppContext'

const LEVELS = ['beginner', 'intermediate', 'advanced', 'olympiad', 'imo']
const levelInfo = {
  beginner: { label: 'Pemula', color: '#2a7a2a', bg: '#e8f8e8', desc: 'Cocok untuk pemula' },
  intermediate: { label: 'Menengah', color: '#9a7220', bg: '#fdf3dc', desc: 'Setara OSN Kabupaten' },
  advanced: { label: 'Lanjutan', color: '#9a4e2e', bg: '#faeee8', desc: 'Setara OSN Provinsi' },
  olympiad: { label: 'Olimpiade', color: '#6a3a9a', bg: '#f0ebf8', desc: 'Setara OSN Nasional' },
  imo: { label: 'IMO', color: '#c4a020', bg: '#1a1610', desc: 'Level internasional' },
}

export default function Quiz() {
  const { addPoints } = useApp()
  const [phase, setPhase] = useState('select') // select | quiz | result
  const [chosenLevel, setChosenLevel] = useState(null)
  const [current, setCurrent] = useState(0)
  const [answers, setAnswers] = useState({})
  const [showHint, setShowHint] = useState(false)
  const [showAns, setShowAns] = useState(false)
  const [score, setScore] = useState(0)

  const questions = chosenLevel ? quizData[chosenLevel] || [] : []
  const q = questions[current]

  const startQuiz = (level) => {
    setChosenLevel(level)
    setCurrent(0)
    setAnswers({})
    setScore(0)
    setShowHint(false)
    setShowAns(false)
    setPhase('quiz')
  }

  const handleAnswer = (idx) => {
    if (answers[current] !== undefined) return
    setAnswers(prev => ({ ...prev, [current]: idx }))
    setShowAns(true)
  }

  const nextQ = () => {
    if (current + 1 < questions.length) {
      setCurrent(c => c + 1)
      setShowHint(false)
      setShowAns(false)
    } else {
      // Calculate score
      let pts = 0
      questions.forEach((q2, i) => { if (answers[i] === q2.ans) pts += q2.xp })
      setScore(pts)
      addPoints(pts)
      setPhase('result')
    }
  }

  if (phase === 'select') return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.title}>Pilih Level Kuis</h1>
        <p style={s.desc}>Uji kemampuanmu dan kumpulkan poin XP. Jawab dengan benar untuk mendapat lebih banyak poin!</p>
      </div>
      <div style={s.levelGrid}>
        {LEVELS.map(l => {
          const li = levelInfo[l]
          const qs = quizData[l] || []
          return (
            <button key={l} onClick={() => startQuiz(l)} style={{ ...s.levelCard, borderColor: `${li.color}33` }}>
              <div style={{ ...s.levelBadge, background: li.bg, color: li.color }}>{li.label}</div>
              <div style={s.levelCardDesc}>{li.desc}</div>
              <div style={s.levelMeta}>
                <span>{qs.length} soal</span>
                <span>+{qs.reduce((a, q2) => a + q2.xp, 0)} XP maks</span>
              </div>
              <div style={{ ...s.startBtn, background: li.color }}>Mulai →</div>
            </button>
          )
        })}
      </div>
    </div>
  )

  if (phase === 'result') {
    const total = questions.reduce((a, q2) => a + q2.xp, 0)
    const correct = questions.filter((q2, i) => answers[i] === q2.ans).length
    const pct = Math.round((correct / questions.length) * 100)
    return (
      <div style={s.wrap}>
        <div style={s.resultCard}>
          <div style={s.resultEmoji}>{pct >= 80 ? '🏆' : pct >= 60 ? '🎉' : pct >= 40 ? '💪' : '📚'}</div>
          <h2 style={s.resultTitle}>Kuis Selesai!</h2>
          <div style={s.resultScore}>{score} <span style={{ fontSize: 18, color: 'var(--muted)' }}>/ {total} XP</span></div>
          <div style={s.resultPct}>{pct}% benar</div>
          <div style={s.resultMeta}>{correct} dari {questions.length} soal terjawab benar</div>
          <div style={s.resultMsg}>
            {pct >= 80 ? 'Luar biasa! Kamu menguasai level ini.' : pct >= 60 ? 'Bagus! Sedikit lagi sempurna.' : 'Terus belajar! Setiap kesalahan adalah pelajaran berharga.'}
          </div>
          <div style={s.resultReview}>
            {questions.map((q2, i) => (
              <div key={i} style={{ ...s.reviewItem, background: answers[i] === q2.ans ? '#e8f8e8' : '#fff0f0' }}>
                <span>{answers[i] === q2.ans ? '✅' : '❌'}</span>
                <span style={{ flex: 1, fontSize: 13 }}>{q2.q}</span>
                <span style={{ fontSize: 12, color: answers[i] === q2.ans ? '#2a7a2a' : '#c44', fontWeight: 600 }}>
                  {answers[i] === q2.ans ? `+${q2.xp}` : `0/${q2.xp}`} XP
                </span>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
            <button onClick={() => startQuiz(chosenLevel)} style={s.retryBtn}>Ulangi Kuis</button>
            <button onClick={() => setPhase('select')} style={s.backBtn2}>Pilih Level Lain</button>
          </div>
        </div>
      </div>
    )
  }

  // Quiz phase
  const li = levelInfo[chosenLevel]
  const answered = answers[current] !== undefined
  const isCorrect = answered && answers[current] === q.ans
  const progress = ((current) / questions.length) * 100

  return (
    <div style={s.wrap}>
      <div style={s.quizCard}>
        {/* Header */}
        <div style={s.quizTop}>
          <button onClick={() => setPhase('select')} style={s.qBackBtn}>←</button>
          <div style={{ flex: 1 }}>
            <div style={s.quizProgress}>
              <span style={{ fontSize: 13, color: 'var(--muted)' }}>Soal {current + 1} / {questions.length}</span>
              <span style={{ ...s.qLevel, background: li.bg, color: li.color }}>{li.label}</span>
            </div>
            <div style={s.progressBarWrap}>
              <div style={{ ...s.progressFill, width: `${progress}%` }} />
            </div>
          </div>
        </div>

        {/* Question */}
        <div style={s.questionWrap}>
          <div style={s.xpBadge}>+{q.xp} XP</div>
          <div style={s.questionText}>{q.q}</div>
        </div>

        {/* Options */}
        <div style={s.options}>
          {q.opts.map((opt, i) => {
            let optStyle = s.option
            if (answered) {
              if (i === q.ans) optStyle = { ...s.option, ...s.optionCorrect }
              else if (i === answers[current]) optStyle = { ...s.option, ...s.optionWrong }
              else optStyle = { ...s.option, ...s.optionDisabled }
            }
            return (
              <button key={i} onClick={() => handleAnswer(i)} style={optStyle} disabled={answered}>
                <span style={s.optLabel}>{String.fromCharCode(65 + i)}</span>
                <span>{opt}</span>
                {answered && i === q.ans && <span style={{ marginLeft: 'auto' }}>✅</span>}
                {answered && i === answers[current] && i !== q.ans && <span style={{ marginLeft: 'auto' }}>❌</span>}
              </button>
            )
          })}
        </div>

        {/* Hint */}
        {q.hint && !answered && (
          <button onClick={() => setShowHint(true)} style={s.hintBtn} disabled={showHint}>
            💡 {showHint ? q.hint : 'Tampilkan Petunjuk'}
          </button>
        )}

        {/* Feedback & next */}
        {answered && (
          <div style={{ ...s.feedback, background: isCorrect ? '#e8f8e8' : '#fff0f0' }}>
            <div style={{ fontWeight: 600, color: isCorrect ? '#2a7a2a' : '#c44', marginBottom: 4 }}>
              {isCorrect ? `🎉 Benar! +${q.xp} XP` : '😅 Kurang tepat'}
            </div>
            {q.hint && <div style={{ fontSize: 13, color: 'var(--muted)' }}>💡 {q.hint}</div>}
            <button onClick={nextQ} style={s.nextBtn}>
              {current + 1 < questions.length ? 'Soal Berikutnya →' : 'Lihat Hasil →'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

const s = {
  wrap: { maxWidth: 800, margin: '0 auto', padding: '28px 20px', animation: 'fadeIn 0.4s ease' },
  header: { marginBottom: 32, textAlign: 'center' },
  title: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(24px, 4vw, 36px)', color: 'var(--ink)', marginBottom: 8 },
  desc: { color: 'var(--muted)', fontSize: 15 },
  levelGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20 },
  levelCard: { background: 'white', border: '2px solid', borderRadius: 'var(--radius-xl)', padding: '24px 20px', cursor: 'pointer', textAlign: 'left', transition: 'transform 0.2s, box-shadow 0.2s', display: 'flex', flexDirection: 'column', gap: 10 },
  levelBadge: { display: 'inline-block', padding: '5px 14px', borderRadius: 20, fontSize: 13, fontWeight: 700 },
  levelCardDesc: { fontSize: 13, color: 'var(--muted)', lineHeight: 1.5 },
  levelMeta: { display: 'flex', gap: 12, fontSize: 12, color: 'var(--muted-light)', fontFamily: 'var(--font-mono)' },
  startBtn: { color: 'white', borderRadius: 10, padding: '10px 0', fontSize: 14, fontWeight: 600, textAlign: 'center', marginTop: 4 },
  quizCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '28px', boxShadow: 'var(--shadow-medium)' },
  quizTop: { display: 'flex', gap: 14, alignItems: 'center', marginBottom: 28 },
  qBackBtn: { background: 'var(--warm-white)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', fontSize: 16, cursor: 'pointer' },
  quizProgress: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  qLevel: { fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20 },
  progressBarWrap: { height: 6, background: 'var(--parchment)', borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', background: 'linear-gradient(90deg, var(--sage), var(--sage-dark))', borderRadius: 3, transition: 'width 0.4s ease' },
  questionWrap: { marginBottom: 24, position: 'relative' },
  xpBadge: { position: 'absolute', top: 0, right: 0, background: 'var(--warm-white)', border: '1px solid var(--amber-light)', borderRadius: 20, padding: '3px 12px', fontSize: 12, fontWeight: 700, color: '#9a7220', fontFamily: 'var(--font-mono)' },
  questionText: { fontFamily: 'var(--font-serif)', fontSize: 'clamp(16px, 2.5vw, 20px)', color: 'var(--ink)', lineHeight: 1.6, paddingRight: 80 },
  options: { display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 },
  option: { display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', background: 'var(--cream)', border: '1.5px solid var(--border)', borderRadius: 12, cursor: 'pointer', fontSize: 15, textAlign: 'left', transition: 'all 0.15s' },
  optionCorrect: { background: '#e8f8e8', border: '1.5px solid #2a7a2a', color: '#2a7a2a' },
  optionWrong: { background: '#fff0f0', border: '1.5px solid #c44', color: '#c44' },
  optionDisabled: { opacity: 0.5, cursor: 'default' },
  optLabel: { width: 28, height: 28, background: 'var(--parchment)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, flexShrink: 0 },
  hintBtn: { width: '100%', background: '#fffbeb', border: '1px dashed var(--amber)', borderRadius: 10, padding: '10px 16px', fontSize: 13, color: '#9a7220', cursor: 'pointer', textAlign: 'left', marginBottom: 8 },
  feedback: { borderRadius: 12, padding: '16px', marginTop: 8 },
  nextBtn: { marginTop: 12, background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 10, padding: '10px 24px', fontSize: 14, fontWeight: 600, cursor: 'pointer' },
  resultCard: { background: 'white', border: '1px solid var(--border-light)', borderRadius: 'var(--radius-xl)', padding: '40px 32px', textAlign: 'center', boxShadow: 'var(--shadow-large)' },
  resultEmoji: { fontSize: 64, marginBottom: 16 },
  resultTitle: { fontFamily: 'var(--font-serif)', fontSize: 28, marginBottom: 8 },
  resultScore: { fontFamily: 'var(--font-mono)', fontSize: 48, fontWeight: 700, color: 'var(--sage-dark)', marginBottom: 4 },
  resultPct: { fontSize: 20, fontWeight: 600, color: 'var(--ink)', marginBottom: 4 },
  resultMeta: { color: 'var(--muted)', fontSize: 14, marginBottom: 16 },
  resultMsg: { background: 'var(--warm-white)', borderRadius: 10, padding: '12px 20px', fontSize: 14, color: 'var(--ink-light)', marginBottom: 20 },
  resultReview: { display: 'flex', flexDirection: 'column', gap: 8, textAlign: 'left' },
  reviewItem: { display: 'flex', gap: 10, alignItems: 'center', padding: '10px 14px', borderRadius: 10 },
  retryBtn: { flex: 1, background: 'var(--sage-dark)', color: 'white', border: 'none', borderRadius: 10, padding: '12px 0', fontSize: 15, fontWeight: 600, cursor: 'pointer' },
  backBtn2: { flex: 1, background: 'var(--warm-white)', color: 'var(--ink)', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 0', fontSize: 15, cursor: 'pointer' },
}
