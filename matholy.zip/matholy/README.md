# 🧮 MathOly — Platform Olimpiade Matematika

Platform belajar matematika olimpiade lengkap dari OSN hingga IMO. Dibangun untuk mendukung pelajar Indonesia yang ingin meniti jalan menuju podium matematika dunia.

![MathOly Preview](https://img.shields.io/badge/React-18-blue) ![Vite](https://img.shields.io/badge/Vite-5-green) ![License](https://img.shields.io/badge/license-MIT-purple)

---

## ✨ Fitur Lengkap

### 📚 Materi Bertahap
- **5 Level**: Pemula → Menengah → Lanjutan → Olimpiade → IMO
- **4 Topik**: Aljabar, Geometri, Kombinatorik, Teori Bilangan
- Konten interaktif dengan formula, contoh soal, dan penjelasan bertahap
- Sistem XP: selesaikan materi → kumpulkan poin

### ✏️ Kuis Interaktif
- Soal dari 5 level kesulitan
- Petunjuk (hint) untuk soal yang sulit
- Umpan balik instan + rekap hasil
- Poin XP otomatis masuk ke profil

### 🧩 Bank Soal Lengkap
- Soal dari **SD hingga IMO**
- Sumber: OSN, AIME, USAMO, Baltic Way, Kangaroo Math, IMO Shortlist
- Filter berdasarkan jenjang, sumber, topik, dan kata kunci
- Kunci jawaban tersedia

### 📄 Referensi PDF
- ABTJOG, AGMO Materials, Olympiad Combinatorics
- IMO Compendium, Geometry Revisited, Problems in Inequalities
- Soal OSN lengkap 2010–2023

### 🏆 Papan Peringkat Bulanan
- Leaderboard real-time berdasarkan poin
- Lencana bulanan: 🥇🥈🥉🔥⚡📚
- Statistik pribadi: streak, poin, lencana

### 📰 Berita & Majalah Olimpiade
- Prestasi tim Indonesia (IMO, APMO, dll)
- Jadwal dan info kompetisi terkini
- Fakta menarik & profil matematikawan dunia
- Pembahasan soal terkini

### 🎯 Info Kompetisi & Lomba
- OSN, IMO, APMO, AIME, KSM, ITMO, dll
- Status pendaftaran real-time
- Notifikasi lomba mendatang

### 💬 Forum Diskusi
- Buat thread diskusi per topik
- Balas dan berinteraksi sesama pelajar
- Thread disematkan untuk topik penting

---

## 🚀 Cara Menjalankan

### Prerequisites
- Node.js 18+
- npm atau yarn

### Instalasi

```bash
# Clone repository
git clone https://github.com/username/matholy.git
cd matholy

# Install dependencies
npm install

# Jalankan development server
npm run dev
```

Buka browser di `http://localhost:5173`

### Build untuk Production

```bash
npm run build
npm run preview
```

---

## 🔑 Akun Demo

| Email | Password | Keterangan |
|-------|----------|------------|
| budi@mail.com | 1234 | User dengan poin tinggi |
| sari@mail.com | 1234 | User menengah |
| ahmad@mail.com | 1234 | User lanjutan |

Atau buat akun baru dari halaman registrasi.

---

## 🏗️ Struktur Proyek

```
src/
├── context/
│   └── AppContext.jsx        # Global state (auth, poin, notifikasi)
├── components/
│   └── layout/
│       ├── Navbar.jsx         # Navigasi + profil dropdown
│       └── Notifications.jsx  # Toast notifikasi
├── pages/
│   ├── Landing.jsx            # Halaman utama + login/register
│   ├── Home.jsx               # Dashboard pengguna
│   ├── Materials.jsx          # Materi bertahap
│   ├── Quiz.jsx               # Kuis interaktif
│   ├── Problems.jsx           # Bank soal
│   ├── PDFs.jsx               # Referensi & unduhan
│   ├── Leaderboard.jsx        # Papan peringkat bulanan
│   ├── News.jsx               # Berita & majalah
│   ├── Competitions.jsx       # Info lomba
│   └── Forum.jsx              # Forum diskusi
├── data/
│   └── index.js               # Semua data: materi, soal, berita, dll
├── App.jsx                    # Router utama
├── main.jsx                   # Entry point
└── index.css                  # Design system & global styles
```

---

## 🎨 Design System

**Palet Warna** (Soft & Nyaman):
- Cream/Parchment: latar belakang hangat
- Sage Green: aksen utama
- Terracotta & Amber: aksen sekunder
- Ink Dark: teks utama

**Font**:
- `Lora` (Serif): judul & heading
- `DM Sans`: body text
- `JetBrains Mono`: formula & kode

---

## 🛠️ Tech Stack

| Teknologi | Kegunaan |
|-----------|----------|
| React 18 | UI Framework |
| Vite 5 | Build tool |
| Lucide React | Icons |
| CSS Variables | Design tokens |
| React Context | State management |

> Tidak ada backend — semua data tersimpan di state (in-memory). Untuk produksi, integrasikan dengan Supabase/Firebase untuk persistensi data.

---

## 🔮 Pengembangan Selanjutnya

- [ ] Backend dengan Supabase (auth, database, storage)
- [ ] Render LaTeX/MathJax untuk formula
- [ ] Upload soal oleh pengguna
- [ ] Sistem komentar forum lebih lengkap
- [ ] Notifikasi push untuk lomba
- [ ] Mode gelap (dark mode)
- [ ] Mobile app (React Native)
- [ ] AI tutor terintegrasi

---

## 📄 Lisensi

MIT License — bebas digunakan untuk keperluan edukasi.

---

## 🤝 Kontribusi

Pull request sangat disambut! Lihat [CONTRIBUTING.md](CONTRIBUTING.md) untuk panduan kontribusi.

---

*Dibuat dengan ❤️ untuk komunitas olimpiade matematika Indonesia*
